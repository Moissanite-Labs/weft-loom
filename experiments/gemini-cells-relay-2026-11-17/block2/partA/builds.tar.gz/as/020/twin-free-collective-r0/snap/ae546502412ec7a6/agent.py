"""Harness for a cell: loop, prompt, and two built-in tools (sh and write)."""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cellapi  # noqa: E402

OBS_CAP = 2000
REPLY_CAP = 1200
MAX_PROMPT = 15000
MAX_STEPS = 40
TASK_CAP = 3000
RULES_CAP = 4000
LISTING_CAP = 800
SAMPLE_CAP = 800
SH_TIMEOUT = 15

SYSTEM = (
    "You are a cell in a small harness. Your folder holds TASK.md and rules files. "
    "Each reply must contain exactly ONE action and nothing else:\n"
    "  @sh, then commands, then @end: runs bash in the task folder (python3 available)\n"
    "  @write <path>, then file content, then @end: creates or overwrites a file\n"
    "  @done: only after the required output file exists and has been checked\n"
    "Method: read every rules file in full first. Then write one python3 solver (standard "
    "library only) that implements EVERY rule in the order written. If an example/ folder "
    "with an expected answer exists, run the solver on it and compare, then run it on the "
    "real data. Check that the output file exists, is valid JSON, and has the exact shape "
    "the task asks for. Fix errors and rerun. Do not invent rules."
)


def read_text(path, cap):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            s = f.read()
    except OSError:
        return ""
    if len(s) > cap:
        s = s[:cap] + "\n...(truncated)"
    return s


def listing(cwd):
    out = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith(".") and d != "__pycache__")
        if root[len(cwd):].count(os.sep) >= 2:
            dirs[:] = []
        for f in sorted(files):
            if f.startswith("."):
                continue
            p = os.path.join(root, f)
            out.append("%s (%d bytes)" % (os.path.relpath(p, cwd), os.path.getsize(p)))
        if len(out) >= 60:
            break
    return "\n".join(out[:60])[:LISTING_CAP]


def rules_text(cwd):
    names = [n for n in os.listdir(cwd)
             if n.endswith((".md", ".txt")) and n != "TASK.md" and os.path.isfile(os.path.join(cwd, n))]
    names.sort(key=lambda n: (n.upper() != "FORMAT.MD", n))
    parts = ["--- %s\n%s" % (n, read_text(os.path.join(cwd, n), RULES_CAP)) for n in names]
    s = "\n".join(parts)
    return s[:RULES_CAP]


def samples(cwd):
    out = []
    for sub in ("data", "example"):
        d = os.path.join(cwd, sub)
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d))[:3]:
            p = os.path.join(d, f)
            if os.path.isfile(p):
                head = read_text(p, 300).splitlines()[:3]
                out.append("%s/%s:\n%s" % (sub, f, "\n".join(head)))
    return "\n".join(out)[:SAMPLE_CAP]


def build_head(cwd):
    task = read_text(os.path.join(cwd, "TASK.md"), TASK_CAP)
    return ("TASK.md:\n" + task + "\n\nFiles in the folder:\n" + listing(cwd)
            + "\n\nRules files:\n" + rules_text(cwd) + "\n\nSample lines:\n" + samples(cwd) + "\n\n")


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s == "@done":
            return ("done", None, None)
        if s == "@sh" or s.startswith("@sh "):
            return ("sh", None, collect(lines, i + 1))
        if s.startswith("@write"):
            return ("write", s[len("@write"):].strip(), collect(lines, i + 1))
    return None


def collect(lines, start):
    out = []
    for line in lines[start:]:
        if line.strip() == "@end":
            break
        out.append(line)
    return "\n".join(out) + "\n"


def run_sh(cmd, cwd):
    try:
        p = subprocess.run(["bash", "-c", cmd], cwd=cwd, capture_output=True,
                           text=True, timeout=SH_TIMEOUT)
        return (p.stdout or "") + (p.stderr or "") + "\n[exit %d]" % p.returncode
    except subprocess.TimeoutExpired:
        return "timed out after %d s" % SH_TIMEOUT
    except Exception as e:
        return "tool error: %r" % (e,)


def write_file(arg, body, cwd):
    if not arg:
        return "write needs a path"
    try:
        path = os.path.join(cwd, arg)
        os.makedirs(os.path.dirname(path) or cwd, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(body)
        return "wrote %d bytes to %s" % (len(body), arg)
    except Exception as e:
        return "tool error: %r" % (e,)


def cap_obs(out):
    if len(out) > OBS_CAP:
        half = OBS_CAP // 2
        return out[:half] + "\n...(output cut)...\n" + out[-half:]
    return out


def select(history, budget):
    if budget <= 0 or not history:
        return ""
    parts, used = [], 0
    for item in reversed(history):
        if used + len(item) > budget:
            if not parts:
                parts.append(item[-budget:])
            break
        parts.append(item)
        used += len(item)
    parts.reverse()
    return "".join(parts)


def main():
    cwd = os.getcwd()
    history = []
    for _ in range(MAX_STEPS):
        try:
            left = cellapi.calls_left()
        except Exception:
            left = None
        if left is not None and left <= 0:
            break
        head = build_head(cwd)
        tail = "\nCalls left: %s\nYour next action:" % (left if left is not None else "unknown")
        budget = MAX_PROMPT - len(SYSTEM) - len(head) - len(tail) - 100
        prompt = head + select(history, budget) + tail
        try:
            reply = str(cellapi.brain(SYSTEM, prompt) or "")
        except Exception:
            break
        kept = reply[:REPLY_CAP]
        action = parse(reply)
        if action is None:
            history.append("Your reply:\n" + kept +
                           "\nResult: Could not read an action. Reply with exactly one @sh, @write or @done block.\n")
            continue
        kind, arg, body = action
        if kind == "done":
            break
        if kind == "sh":
            obs = run_sh(body, cwd)
        else:
            obs = write_file(arg, body, cwd)
        history.append("Your reply:\n" + kept + "\nResult:\n" + cap_obs(obs) + "\n")
    return 0


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("harness error: %r" % (e,))
        sys.exit(0)
