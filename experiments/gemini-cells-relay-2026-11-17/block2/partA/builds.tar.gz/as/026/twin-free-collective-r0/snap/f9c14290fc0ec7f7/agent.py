import os
import subprocess

import cellapi

END = "@" + "end"
MAX_PROMPT = 14000
MAX_TASK = 5000
MAX_OBS = 1800
MAX_SHOWN = 1000
MAX_STEPS = 8

SYSTEM = (
    "You are a cell in a small agent harness. Each reply is exactly one action:\n\n"
    "@sh\n<shell commands>\n" + END + "\n\n"
    "@write <path>\n<file content>\n" + END + "\n\n"
    "@done\n\n"
    "Rules:\n"
    "- Your first action must do real work: read the files the task names in full "
    "(use sed -n in parts if long), and in the same command make a first attempt at the solution.\n"
    "- Never spend a call only listing or reading files. The folder listing is already shown.\n"
    "- Check every stated rule, including edge cases, not only the examples.\n"
    "- Use python3 with the standard library. Print short summaries only, since output is cut.\n"
    "- Run your solver on any worked example and compare before using the real data.\n"
    "- Write the required output file in the exact required format. Partial output beats none.\n"
    "- Check the result by running python3 before you send @done.\n"
    "- Send @done only when the required output is written and checked, or when no calls are left.\n"
)


def clip(text, n):
    text = text or ""
    if len(text) <= n:
        return text
    return text[: (n * 2) // 3] + "\n...[cut]...\n" + text[-(n // 3):]


def collect(lines, start):
    out = []
    for line in lines[start:]:
        if line.strip() == END:
            break
        out.append(line)
    return "\n".join(out).strip("\n")


def parse(reply):
    lines = [l for l in (reply or "").replace("\r\n", "\n").split("\n")
             if not l.strip().startswith("```")]
    for i, line in enumerate(lines):
        s = line.strip()
        if s == "@done":
            return ("done", "", "")
        if s == "@sh" or s.startswith("@sh "):
            return ("sh", "", collect(lines, i + 1))
        if s.startswith("@write"):
            return ("write", s[len("@write"):].strip().strip('"\''), collect(lines, i + 1))
    return None


def run_sh(cmd, cwd):
    try:
        p = subprocess.run(["bash", "-c", cmd], cwd=cwd, capture_output=True,
                           text=True, timeout=18, stdin=subprocess.DEVNULL)
        out = (p.stdout or "") + (p.stderr or "")
        code = str(p.returncode)
    except subprocess.TimeoutExpired:
        out, code = "timeout after 18 s", "timeout"
    return "exit " + code + "\n" + clip(out, MAX_OBS)


def run_write(path, body, cwd):
    if not path:
        return "Write failed: no path."
    root = os.path.realpath(cwd)
    full = os.path.realpath(os.path.join(root, path))
    if full != root and not full.startswith(root + os.sep):
        return "Refused: path outside the task folder."
    try:
        d = os.path.dirname(full)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(body if body.endswith("\n") else body + "\n")
        return "Wrote " + path + " (" + str(len(body)) + " chars)."
    except Exception as e:
        return "Write failed: " + str(e)


def listing(cwd):
    items = []
    for dp, dn, fn in os.walk(cwd):
        dn[:] = [d for d in dn if not d.startswith(".")]
        for f in fn:
            p = os.path.join(dp, f)
            try:
                size = os.path.getsize(p)
            except OSError:
                size = -1
            items.append(os.path.relpath(p, cwd) + " (" + str(size) + " bytes)")
        if len(items) > 200:
            break
    return clip("\n".join(sorted(items)[:200]), 1000)


def build_prompt(task, files, history, left):
    head = ("TASK.md:\n" + clip(task, MAX_TASK) + "\n\nFiles in your folder:\n"
            + files + "\n\n")
    tail = "\nModel calls left: " + str(left) + "."
    if left <= 1:
        tail += " This is your last call: send @done if the output is written and checked."
    tail += " Your next action:"
    note = "(older steps omitted to save space)\n"
    budget = MAX_PROMPT - len(head) - len(tail) - len(note) - 20
    kept, total = [], 0
    for entry in reversed(history):
        if total + len(entry) > budget:
            break
        kept.append(entry)
        total += len(entry)
    kept.reverse()
    prefix = note if len(kept) < len(history) else ""
    return head + prefix + "".join(kept) + tail


def main():
    cwd = os.getcwd()
    try:
        with open(os.path.join(cwd, "TASK.md"), encoding="utf-8", errors="replace") as f:
            task = f.read()
    except Exception:
        task = ""
    files = listing(cwd)
    history = []
    for _ in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, files, history, left)
        try:
            reply = cellapi.brain(SYSTEM, prompt)
        except Exception:
            break
        action = parse(reply or "")
        if action is None:
            history.append("Your reply had no action. Reply with exactly one @sh, @write or @done block.\n\n")
            continue
        kind, arg, body = action
        if kind == "done":
            break
        if kind == "sh":
            obs = run_sh(body, cwd)
            shown = "@sh\n" + clip(body, MAX_SHOWN) + "\n" + END
        else:
            obs = run_write(arg, body, cwd)
            shown = "@write " + arg + "\n" + clip(body, MAX_SHOWN) + "\n" + END
        history.append("Your action:\n" + shown + "\nResult:\n" + clip(obs, MAX_OBS) + "\n\n")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
END
