"""Harness for cell runs. Loop, prompt and tools. Run with the task folder as cwd."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
PROMPT_CAP = 15000       # hard cap on characters of system + prompt sent per call
OBS_CAP = 3500           # characters of tool output shown back to the model
OBS_HEAD = 2200          # kept from the start of a long output
OBS_TAIL = 1100          # kept from the end (verification lines live there)
PRELOAD_CAP = 6000       # characters of task files shown in the first prompt
PRELOAD_FILE_CAP = 3000  # per spec file in the preload
TASK_CAP = 3000          # characters of TASK.md shown in each prompt
HIST_CAP = 4500          # characters of earlier steps kept in each prompt
MAX_STEPS = 40

EXTRA = """
Working rules (important):
- You have very few model calls (about 3). Never spend a call only listing or reading files
  that the first prompt already shows. Your first action must do real work.
- First action: read every spec file in full (cat each whole file; if a file is longer than
  the output limit, read it with sed -n in two parts). In the same command, write a complete
  solver or fix and run it.
- Data tasks: implement every rule in FORMAT.md exactly (delimiter, column order, timestamp
  pattern, amount style, excluded statuses, duplicate resolution, currency conversion,
  rounding, boundary rules). If an example with expected output exists, run the solver on it
  and compare before using the real data. Then run on the real data and write the required
  output file in the exact required format (keys, types, rounding).
- Bugfix tasks: read SPEC.md fully and check each function against every stated rule and
  worked example, including edge cases. Each module has exactly one bug: find it, fix it in
  place, keep names and signatures, and run a quick check that the module imports and the
  spec examples pass.
- Write the required output file even if you are unsure of some rules; partial credit counts.
- Output is cut at about 3500 characters: use head, tail, grep or wc to see what matters.
- Use python3 with decimal or round() as the spec requires. Keep scratch scripts out of the
  task data.
- Do not send a done marker until the required output is written and checked.
"""


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def read_head(path, cap):
    try:
        with open(path, errors="replace") as f:
            return f.read(cap)
    except OSError:
        return ""


def preview(cwd):
    """File list plus the text of spec files and expected answers, within PRELOAD_CAP."""
    names = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for fn in sorted(files):
            rel = os.path.relpath(os.path.join(root, fn), cwd)
            if rel != "TASK.md":
                names.append(rel)
    names = names[:80]
    out = ["FILES (relative to the task folder): " + " ".join(names)]
    budget = PRELOAD_CAP
    spec = [n for n in names if n.endswith(".md")]
    spec += [n for n in names if n.endswith("expected.json") and n not in spec]
    spec += [n for n in names if n.endswith(".txt") and n not in spec and "/data/" not in n]
    spec += [n for n in names if n.endswith(".json") and n not in spec and "/data/" not in n]
    other = [n for n in names if n not in spec]
    for rel in spec:
        if budget <= 200:
            break
        text = read_head(os.path.join(cwd, rel), min(budget - 100, PRELOAD_FILE_CAP))
        if text:
            block = f"\n== {rel}\n{text}\n"
            out.append(block)
            budget -= len(block)
    for rel in other[:4]:
        if budget <= 300:
            break
        text = read_head(os.path.join(cwd, rel), min(budget - 200, 400))
        if text:
            block = f"\n== {rel} (head)\n{text}\n"
            out.append(block)
            budget -= len(block)
    return "\n".join(out)


def cut(obs):
    if len(obs) <= OBS_CAP:
        return obs
    return obs[:OBS_HEAD] + "\n[... cut ...]\n" + obs[-OBS_TAIL:]


def build_prompt(system, task, pre, history, left):
    head = "TASK.md:\n" + task[:TASK_CAP] + "\n\nPRELOADED TASK FILES:\n" + pre + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    if left <= 1:
        tail = ("\nModel calls left: 1. This is your LAST model call: the required output "
                "must be written in this action.\nYour next action:")
    room = min(PROMPT_CAP - len(system) - len(head) - len(tail), HIST_CAP)
    hist = "".join(history)
    if len(hist) > room:
        keep = max(room - 40, 0)
        hist = "[earlier steps cut]\n" + (hist[-keep:] if keep else "")
    return head + hist + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + EXTRA + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    pre = preview(cwd)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(system, task, pre, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = cut(str(obs))
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
