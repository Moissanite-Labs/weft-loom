import os
import re
import subprocess

try:
    import cellapi
except Exception:
    cellapi = None

ROOT = os.getcwd()

SYSTEM = (
    "You solve one task in a folder by writing files and running shell commands. "
    "Reply with one or more of these blocks and nothing else:\n"
    "@sh\n<shell commands>\n@end\n"
    "@write <path>\n<file content>\n@end\n"
    "@done\n"
    "Write scripts with @write (python3 is available) and run them with @sh. "
    "The deliverable is the file named in TASK.md (usually answer.json), in the exact format TASK.md asks for. "
    "Read FORMAT.md and SPEC.md rules carefully, including edge cases the examples do not cover. "
    "After running, check the output and the file. Reply @done only when the answer file is written and checked."
)

ACTION_RE = re.compile(r"^@(sh|write)[ \t]*(\S*)[ \t]*\n(.*?)^@end[ \t]*$", re.S | re.M)


def left():
    try:
        return int(cellapi.calls_left())
    except Exception:
        return 3


def brain(system, prompt):
    return str(cellapi.brain(system, prompt))


def clip(s, n):
    return s if len(s) <= n else s[:n] + "\n...[cut]"


def gather():
    names = []
    for d, dirs, files in os.walk(ROOT):
        dirs[:] = [x for x in dirs if x != "__pycache__"]
        for f in files:
            names.append(os.path.relpath(os.path.join(d, f), ROOT))
    names.sort()
    pri = [n for n in ("TASK.md", "FORMAT.md", "SPEC.md") if n in names]
    rest = [n for n in names if n not in pri and n != "agent.py"
            and not n.startswith("tools" + os.sep)]
    out = ["FILES:\n" + "\n".join(names[:200])]
    budget = 11000
    for n in pri + rest:
        if budget <= 0:
            break
        try:
            with open(os.path.join(ROOT, n), encoding="utf-8") as fh:
                body = fh.read()
        except Exception:
            continue
        body = clip(body, min(4000, budget))
        chunk = "\n== %s ==\n%s" % (n, body)
        out.append(chunk)
        budget -= len(chunk)
    return "\n".join(out)


def run_actions(text):
    outs = []
    real_root = os.path.realpath(ROOT)
    for m in ACTION_RE.finditer(text):
        kind, path, body = m.group(1), m.group(2), m.group(3)
        if kind == "write":
            target = os.path.realpath(os.path.join(ROOT, path))
            if not target.startswith(real_root + os.sep):
                outs.append("write refused: " + path)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(target, "w", encoding="utf-8") as fh:
                fh.write(body if body.endswith("\n") else body + "\n")
            outs.append("wrote " + path)
        else:
            try:
                r = subprocess.run(["bash", "-c", body], cwd=ROOT,
                                   capture_output=True, text=True, timeout=20)
                o = (r.stdout or "") + (r.stderr or "")
                outs.append("$ sh output (exit %d):\n%s" % (r.returncode, clip(o, 3000)))
            except Exception as e:
                outs.append("sh error: %s" % e)
    done = re.search(r"^@done", text, re.M) is not None
    return outs, done


def main():
    if cellapi is None:
        return
    base = gather()
    history = ""
    tries = 0
    while tries < 3 and left() > 0:
        tries += 1
        if tries == 1:
            prompt = base
        else:
            prompt = clip(base, 6000) + "\n\nResults of your last actions:\n" + history + \
                "\n\nFix anything wrong, then reply @done."
        prompt = clip(prompt, 15000)
        try:
            reply = brain(SYSTEM, prompt)
        except Exception as e:
            history = "brain error: %s" % e
            break
        outs, done = run_actions(reply)
        history = "\n".join(outs) if outs else \
            "(no actions parsed; reply must use @sh, @write and @done blocks)"
        if done:
            break


if __name__ == "__main__":
    main()
