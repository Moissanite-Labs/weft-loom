"""Harness for a file-based task folder (cell harness, turn 1 rewrite)."""
import os
import re
import subprocess

try:
    import cellapi
except Exception:  # pragma: no cover
    cellapi = None

ROOT = os.getcwd()
PROMPT_CAP = 13000
SPEC_CAP = 9000
SAMPLE_CAP = 2000
FEEDBACK_CAP = 2500
RUN_CAP = 1800
RUN_TIMEOUT = 120
MAX_ROUNDS = 8

SYSTEM = """You are a careful engineer working in one task folder.
Step 1: read every spec line and list each rule (delimiters, quoting, column
order, comment and continuation lines, separators and split limits, timestamp
format and time zone, case and whitespace, level or status names, filters,
duplicate handling, currency conversion, rounding, edge cases, exact output shape).
Step 2: write ONE complete Python 3 standard-library solver implementing every rule.
Step 3: run it on the example folder, compare with expected output, fix differences.
Step 4: run it on the real data folder and check the required output file exists
with the required shape.

Reply with blocks only, in this exact form (any number, in order):

<<<FILE relative/path
complete file content
>>>

<<<RUN
one shell command, run in the task folder
>>>

When the required output file is written and checked, reply with:

<<<DONE
>>>

Rules:
- Write complete files, never patches. Use bash-compatible commands only.
- Use python3 for comparisons, not process substitution.
- Never repeat a command whose output you already saw.
- Do not say DONE until the output file exists with the required shape."""

FILE_RE = re.compile(r"<<<FILE[ \t]+(\S+)[ \t]*\n(.*?)\n?>>>", re.S)
RUN_RE = re.compile(r"<<<RUN[ \t]*\n(.*?)\n?>>>", re.S)
DONE_RE = re.compile(r"<<<DONE")
SKIP_DIRS = ("__pycache__", ".git")


def read_text(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception as e:
        return "<unreadable: %s>" % e


def clip(s, n):
    if len(s) <= n:
        return s
    head = int(n * 0.6)
    tail = max(n - head - 20, 0)
    return s[:head] + "\n...[cut]...\n" + s[len(s) - tail:]


def spec_text():
    names = sorted(f for f in os.listdir(ROOT)
                   if f.endswith(".md") and os.path.isfile(os.path.join(ROOT, f)))
    if not names:
        return "(no spec files at top level)\n"
    per = max(1200, SPEC_CAP // len(names))
    parts = ["=== SPEC %s ===\n%s\n" % (n, clip(read_text(os.path.join(ROOT, n)), per))
             for n in names]
    return clip("".join(parts), SPEC_CAP)


def data_text():
    out = []
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = [d for d in dns if not d.startswith(".") and d not in SKIP_DIRS]
        rel_dir = os.path.relpath(dp, ROOT)
        if not (rel_dir == "data" or rel_dir.startswith("data" + os.sep)):
            continue
        for fn in sorted(fns):
            p = os.path.join(dp, fn)
            try:
                size = os.path.getsize(p)
            except Exception:
                size = -1
            out.append("--- %s (%d bytes)\n%s\n" % (
                os.path.relpath(p, ROOT), size, clip(read_text(p), 400)))
    if not out:
        return "(no data/ folder found)\n"
    return clip("".join(out), SAMPLE_CAP)


def tree_text():
    lines = []
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = [d for d in dns if not d.startswith(".") and d not in SKIP_DIRS]
        for fn in fns:
            lines.append(os.path.relpath(os.path.join(dp, fn), ROOT))
    return "\n".join(sorted(lines)[:200]) + "\n"


def build_prompt(feedback):
    header = "Working folder: %s\nFiles:\n%s\n" % (ROOT, tree_text())
    fb = "\n".join(feedback)[-FEEDBACK_CAP:] if feedback else "(no feedback yet)"
    prompt = (header + "\n" + spec_text() + "\n" + data_text()
              + "\n=== FEEDBACK SO FAR ===\n" + fb + "\n")
    return prompt[:PROMPT_CAP]


def safe_path(rel):
    full = os.path.normpath(os.path.join(ROOT, rel))
    if full == ROOT or not full.startswith(ROOT + os.sep):
        return None
    return full


def write_file(rel, content):
    full = safe_path(rel)
    if full is None:
        return "refused path %s" % rel
    try:
        d = os.path.dirname(full)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(content.rstrip("\n") + "\n")
        return "wrote %s (%d chars)" % (rel, len(content))
    except Exception as e:
        return "failed to write %s: %s" % (rel, e)


def run_cmd(cmd):
    shell = "/bin/bash" if os.path.exists("/bin/bash") else None
    try:
        p = subprocess.run(cmd, shell=True, cwd=ROOT, executable=shell,
                           capture_output=True, text=True, timeout=RUN_TIMEOUT)
        text = (p.stdout or "") + (p.stderr or "")
        code = p.returncode
    except subprocess.TimeoutExpired:
        text, code = "timeout after %ds" % RUN_TIMEOUT, "timeout"
    except Exception as e:
        text, code = "run error: %s" % e, "error"
    if len(text) > RUN_CAP:
        text = "...[earlier output cut]...\n" + text[-RUN_CAP:]
    return code, text


def calls_left():
    try:
        return int(cellapi.calls_left())
    except Exception:
        return 0


def ask(prompt):
    try:
        return cellapi.brain(SYSTEM, prompt) or ""
    except Exception as e:
        return "<<<ERROR %s" % e


def main():
    feedback = []
    rounds = 0
    while rounds < MAX_ROUNDS and cellapi is not None and calls_left() > 0:
        rounds += 1
        reply = ask(build_prompt(feedback))
        files = FILE_RE.findall(reply)
        runs = RUN_RE.findall(reply)
        done = bool(DONE_RE.search(reply))
        if not files and not runs and not done:
            feedback.append("[round %d] reply had no blocks. Use the exact <<<FILE / <<<RUN / <<<DONE form." % rounds)
            continue
        for rel, content in files:
            feedback.append("[round %d] %s" % (rounds, write_file(rel.strip(), content)))
        for cmd in runs:
            code, text = run_cmd(cmd.strip())
            feedback.append("[round %d] $ %s\n[exit %s]\n%s" % (rounds, cmd.strip()[:200], code, text))
        if done and not runs:
            break


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("harness error: %s" % e)
