"""Seed harness for a cell. Run with the task folder as the working directory.

Changes from the seed: tool output is shown up to 2600 characters (was 1200),
the prompt keeps the newest steps and stays under the referee's prompt limit,
and a failed model call ends the episode cleanly instead of crashing.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2600       # characters of tool output shown back to the model
REPLY_CAP = 1500     # characters of the model's own reply kept in history
PROMPT_CAP = 14000   # system plus prompt stay under the referee's 16000 limit
TASK_CAP = 6000      # longest TASK.md shown in full
MAX_STEPS = 40       # the referee's call cap usually ends the episode first


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def clip(text, cap):
    if len(text) <= cap:
        return text
    return text[:cap] + "\n[cut]"


def build_prompt(system, task, history, left):
    head = "TASK.md:\n" + clip(task, TASK_CAP) + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    budget = min(PROMPT_CAP - len(system), 12000) - len(head) - len(tail)
    kept = []
    used = 0
    for item in reversed(history):          # newest steps first
        if used + len(item) > budget:
            break
        kept.append(item)
        used += len(item)
    kept.reverse()
    if not kept and history and budget > 0:
        kept = [history[-1][-budget:]]      # the newest step alone is too big: keep its end
    note = ""
    if len(kept) < len(history):
        note = "[earlier steps dropped to fit the prompt limit]\n"
    return head + note + "".join(kept) + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    try:
        with open(os.path.join(cwd, "TASK.md")) as f:
            task = f.read()
    except OSError:
        task = "(no TASK.md found)"
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(system, task, history, left)
        try:
            reply = cellapi.brain(system, prompt) or ""
        except cellapi.BudgetExhausted:
            break
        except Exception as exc:
            history.append(f"\n--- step {step + 1} ---\n[model error: {type(exc).__name__}]\n")
            break
        action = parse(reply)
        if action is None:
            obs = ("Could not read an action. Start the reply with @sh or @write <path>, "
                   "and end it with a line containing only @end.")
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}. Known tools: {', '.join(tools)}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = clip(str(obs), OBS_CAP)
        history.append(f"\n--- step {step + 1} ---\n{clip(reply.strip(), REPLY_CAP)}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
