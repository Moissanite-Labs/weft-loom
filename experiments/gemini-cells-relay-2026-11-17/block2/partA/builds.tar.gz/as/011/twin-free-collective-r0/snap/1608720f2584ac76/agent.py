"""Harness v2 for cell A. Same loop, tools and cellapi interface as the seed.

Changes: observations are larger, and history is trimmed to fit the 16000-character
prompt limit so the newest steps are always shown. A failed model call ends the episode
cleanly instead of crashing the harness.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000        # characters of tool output shown back to the model
REPLY_CAP = 2000      # characters of each model reply kept in history
TASK_CAP = 6000       # characters of TASK.md shown each call
PROMPT_BUDGET = 14500 # stay under the 16000-character prompt limit
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def clip(text, cap):
    if len(text) <= cap:
        return text
    return text[:cap] + "\n[output cut]"


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = clip(f.read(), TASK_CAP)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        head = "TASK.md:\n" + task + "\n\n"
        tail = f"\nModel calls left: {left}. Your next action:"
        room = PROMPT_BUDGET - len(head) - len(tail)
        kept = []
        total = 0
        for item in reversed(history):
            if total + len(item) > room:
                break
            kept.insert(0, item)
            total += len(item)
        prompt = head + "".join(kept) + tail
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        except Exception as exc:
            print(f"model call failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = clip(str(obs), OBS_CAP)
        history.append(
            f"\n--- step {step + 1} ---\n{clip(reply.strip(), REPLY_CAP)}\n--- result ---\n{obs}\n"
        )


if __name__ == "__main__":
    sys.exit(main())
