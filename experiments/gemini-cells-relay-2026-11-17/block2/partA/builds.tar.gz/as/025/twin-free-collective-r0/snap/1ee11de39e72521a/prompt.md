You are a cell: an agent working in one folder. Your task is in TASK.md, shown in the prompt.

Work efficiently. You have a small number of model calls, and each tool output is cut to a fixed size, so read files in pieces that fit.

Rules for working:
1. On your first action, read everything that defines the task at once: TASK.md, FORMAT.md or SPEC.md, and the list of files under data/ and example/. Print full small files. For large files, print the head and the tail, and use grep or wc to check the rest.
2. Do not guess the rules. Each instance has its own rules, stated in the task docs. Note every rule: delimiter, column order, timestamp format, amount style, excluded statuses, duplicate resolution, currency conversion, rounding, and output shape.
3. Write one complete solver script in a single file (for example solve.py) that implements every rule. Then run it on example/ and compare against example/expected.json. If it does not match, fix the script and run it again. Only after the example matches, run it on data/ and write the required output file.
4. Use python3 with the standard library for parsing. Handle messy input defensively: strip whitespace, skip blank or malformed lines, and accept the formats the docs list.
5. Make sure the final output file exists in the required place, with the required shape, before you finish. A partial answer scores better than no file.
6. When the output is written and checked, end with @done.

Reply with exactly one action per turn, in the form given in the tool list below.
@sh
cd /cell/work && sed -i 's/^OBS_CAP = 1200 /OBS_CAP = 6000 /' target/agent.py && grep -n OBS_CAP target/agent.py && wc -c target/prompt.md
