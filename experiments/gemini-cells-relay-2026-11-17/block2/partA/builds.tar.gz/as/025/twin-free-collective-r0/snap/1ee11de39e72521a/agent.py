"""Harness for a cell. Pre-reads the task folder before the first model call."""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2800
LIMIT = 15000
TASK_CAP = 3000
PRE_CAP = 3500
SPEC_CAP = 2000
LIST_LIMIT = 40
MAX_STEPS = 40
SPEC_NAMES = ("FORMAT.md", "SPEC.md", "README.md")


def read_text(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.read()


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("@") and not s.startswith("@end"):
            head = s[1:].split(None, 1)
            name = head[0] if head else ""
            arg = head[1] if len(head) > 1 else ""
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return name, arg, "\n".join(body)
    return None


def cap(text, n=OBS_CAP):
    if len(text) <= n:
        return text
    half = n // 2
    return text[:half] + "\n...[cut %d chars]...\n" % (len(text) - n) + text[-half:]


def walk_files(cwd):
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith(".") and d != "target")
        for f in sorted(files):
            yield os.path.join(root, f)


def preread(cwd):
    names = []
    specs = []
    for full in walk_files(cwd):
        rel = os.path.relpath(full, cwd)
        if len(names) < LIST_LIMIT:
            try:
                names.append("%s (%d bytes)" % (rel, os.path.getsize(full)))
            except OSError:
                pass
        if os.path.basename(full) in SPEC_NAMES:
            try:
                specs.append("--- %s ---\n%s" % (rel, cap(read_text(full), SPEC_CAP)))
            except OSError:
                pass
    text = "FILES:\n" + "\n".join(names) + "\n\n" + "\n".join(specs)
    return cap(text, PRE_CAP)


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    try:
        task = cap(read_text(os.path.join(cwd, "TASK.md")), TASK_CAP)
    except OSError:
        task = ""
    pre = preread(cwd)

    entries = []
    for _ in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        head = ("TASK.md:\n" + task + "\n\nPRE-READ (done for you; do not spend a call on it):\n"
                + pre + "\n\n")
        tail = "\nModel calls left: %d. Your next action:" % left
        room = LIMIT - len(system) - len(head) - len(tail) - 200
        kept = []
        used = 0
        for reply, obs in reversed(entries):
            block = "[your action]\n" + reply.strip() + "\n[result]\n" + obs + "\n\n"
            if used + len(block) > room:
                break
            kept.append(block)
            used += len(block)
        history = "".join(reversed(kept))
        if len(kept) < len(entries):
            history = "[earlier steps dropped to fit the prompt limit]\n" + history
        prompt = head + history + tail

        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = "Unknown tool %s." % action[0]
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as e:
                obs = "Tool error: %r" % (e,)
        entries.append((reply, cap(str(obs))))


if __name__ == "__main__":
    main()
