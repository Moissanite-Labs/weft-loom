"""Harness v2 for cell B. The task spec is preloaded into the first prompt, so the cell
can read the rules without spending model calls on reading, and observations are not
cut as early."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2500       # characters of tool output shown back to the model
BRIEF_CAP = 9000     # characters of spec preloaded into the first prompt
PROMPT_CAP = 15000   # keep every prompt under the referee's 16000 limit
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def read_text(path, limit):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            s = f.read()
    except OSError:
        return ""
    if len(s) > limit:
        s = s[:limit] + "\n[cut]"
    return s


def briefing(cwd, budget):
    """Spec files (TASK.md and top-level .md files) in full up to a budget,
    then an inventory of the folder and short samples of the data files."""
    top = sorted(f for f in os.listdir(cwd) if os.path.isfile(os.path.join(cwd, f)))
    order = ["TASK.md"] + [f for f in top if f.endswith(".md") and f != "TASK.md"]
    order = [f for f in order if f in top]
    out = []
    per = max(1500, (budget * 2 // 3) // max(1, len(order)))
    for f in order:
        out.append("== " + f + "\n" + read_text(os.path.join(cwd, f), per) + "\n")
    inv = []
    for root, dirs, files in os.walk(cwd):
        dirs.sort()
        for n in sorted(files):
            p = os.path.relpath(os.path.join(root, n), cwd)
            if p not in order:
                inv.append(p)
    out.append("== files (" + str(len(inv)) + ")\n" + "\n".join(inv[:80]) + "\n")
    samples = 0
    for p in inv:
        if samples >= 6:
            break
        low = p.lower()
        if low.endswith((".txt", ".log", ".csv", ".json")):
            samples += 1
            out.append("== head " + p + "\n" + read_text(os.path.join(cwd, p), 300) + "\n")
    text = "\n".join(out)
    if len(text) > budget + 3000:
        text = text[: budget + 3000] + "\n[brief cut]"
    return "TASK.md and spec files, preloaded by the harness:\n" + text


def make_prompt(brief, history, left):
    tail = "Model calls left: %d. Your next action:" % left
    room = PROMPT_CAP - len(brief) - len(tail) - 200
    chosen = []
    size = 0
    for h in reversed(history):
        if size + len(h) > room:
            break
        chosen.append(h)
        size += len(h)
    chosen.reverse()
    note = "\n[earlier steps omitted]\n" if len(chosen) < len(history) else ""
    return brief + note + "".join(chosen) + "\n" + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    brief = briefing(cwd, BRIEF_CAP)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = make_prompt(brief, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except Exception:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = "Unknown tool " + action[0] + "."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = "Tool error: %s: %s" % (type(exc).__name__, exc)
        obs = str(obs)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append("\n--- step %d ---\n%s\n--- result ---\n%s\n" % (step + 1, reply.strip(), obs))


if __name__ == "__main__":
    sys.exit(main())
