"""Seed harness, improved. The loop, the prompt and the tools a cell starts with.

Run with the task folder as the working directory. The model is reached through cellapi,
which the referee provides.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 6000        # characters of tool output shown back to the model
PRESCAN_CAP = 3000    # characters of folder preview shown in the first prompt
PROMPT_CAP = 13000
TASK_CAP = 8000       # cap on the TASK.md text shown in every prompt    # keep every prompt under the referee's 16000 character limit
MAX_STEPS = 40        # the referee's call cap usually ends the episode first


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def preview(cwd, cap):
    """List the files in the task folder and show the start of small text files."""
    names = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for f in sorted(files):
            rel = os.path.relpath(os.path.join(root, f), cwd)
            if rel != "TASK.md":
                names.append(rel)
    listing = "Files in your folder: " + ", ".join(names[:100])
    parts = [listing]
    used = len(listing)
    for rel in names:
        if used >= cap:
            break
        try:
            with open(os.path.join(cwd, rel), "rb") as fh:
                raw = fh.read(2000)
        except OSError:
            continue
        if b"\0" in raw:
            continue
        text = raw.decode("utf-8", "replace")
        snippet = f"\n== {rel} (first {len(text)} chars)\n{text}"
        snippet = snippet[: cap - used]
        parts.append(snippet)
        used += len(snippet)
    return "\n".join(parts)


def fit_history(history, budget):
    """Keep the most recent steps that fit in the budget."""
    kept = []
    total = 0
    for h in reversed(history):
        if total + len(h) > budget:
            break
        kept.append(h)
        total += len(h)
    return "".join(reversed(kept))


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    task = task[:TASK_CAP]
    pre = preview(cwd, PRESCAN_CAP)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        head = ("TASK.md:\n" + task + "\n\nWorkspace preview (read before your first action):\n"
                + pre + "\n\n")
        tail = f"\nModel calls left: {left}. Your next action:"
        budget = max(PROMPT_CAP - len(head) - len(tail), 1000)
        prompt = head + fit_history(history, budget) + tail
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
