"""Seed harness, improved. The harness gathers task context itself (no model call)."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2000
CONTEXT_CAP = 5000
HISTORY_CAP = 5000
MAX_STEPS = 40

STRATEGY = """
Strategy (few model calls, one action per reply):
- Docs and data heads are already shown under CONTEXT. Do not spend a call on cat/ls/find of them.
- Call 1: write a complete program (e.g. solve.py) implementing every rule exactly, write the output file in the exact format, and in the same @sh run it on the example (if any) and the real data, printing a short comparison with the expected answer.
- Call 2: fix what the comparison showed and rerun.
- Call 3: confirm the output file exists and is valid, then @done.
- Keep tool output short: counts and short diffs only.
"""


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def read_head(path, n):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read(n)
    except OSError as exc:
        return f"<unreadable: {exc}>"


def gather_context(cwd):
    names = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for f in sorted(files):
            if not f.startswith("."):
                names.append(os.path.relpath(os.path.join(root, f), cwd))
    names.sort()
    chunks = [f"FILES ({len(names)}): " + ", ".join(names[:80]) + "\n"]
    for n in names:
        if n != "TASK.md" and n.lower().endswith(".md"):
            chunks.append(f"\n--- {n} ---\n" + read_head(os.path.join(cwd, n), 3000) + "\n")
    for n in names:
        if n.endswith(".py") and not n.startswith("agent"):
            chunks.append(f"\n--- {n} ---\n" + read_head(os.path.join(cwd, n), 1200) + "\n")
    for n in names:
        if "expected" in n or n.endswith((".json", ".txt", ".log", ".csv")):
            chunks.append(f"\n--- {n} (head) ---\n" + read_head(os.path.join(cwd, n), 400) + "\n")
    return "".join(chunks)[:CONTEXT_CAP]


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + STRATEGY + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    try:
        context = gather_context(cwd)
    except Exception as exc:
        context = f"(context unavailable: {exc})"
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        past = "".join(history)[-HISTORY_CAP:]
        prompt = ("TASK.md:\n" + task + "\n\nCONTEXT gathered by the harness (no model call used):\n"
                  + context + "\n\n" + past + f"\nModel calls left: {left}. Your next action:")
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
