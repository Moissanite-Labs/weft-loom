"""Harness for a cell. Run with the task folder as the working directory.

The model is reached only through cellapi.brain(system, prompt). Each reply holds one
action in the form @tool arg ... @end; only the first action runs.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000        # characters of tool output shown back to the model
PROMPT_CAP = 15000    # whole prompt (system + task + history) stays under the 16000 limit
TASK_CAP = 6000       # longest TASK.md copy put into the prompt
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None.

    A body whose @end is missing runs to the end of the reply.
    """
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def build_prompt(task, history, left, system_len):
    head = "TASK.md:\n" + task[:TASK_CAP] + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    budget = PROMPT_CAP - system_len - len(head) - len(tail)
    hist = "".join(history)
    if budget <= 0:
        hist = ""
    elif len(hist) > budget:
        hist = "\n[earlier steps cut]\n" + hist[-(budget - 25):]
    return head + hist + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left, len(system))
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        except Exception as exc:
            obs = f"Model error: {type(exc).__name__}: {exc}"
            history.append(f"\n--- step {step + 1} ---\n[no reply]\n--- result ---\n{obs}\n")
            continue
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = str(obs)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
