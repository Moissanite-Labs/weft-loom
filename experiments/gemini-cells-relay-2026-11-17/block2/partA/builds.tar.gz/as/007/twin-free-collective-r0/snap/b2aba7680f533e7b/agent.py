"""Seed harness v2. Run with the task folder as the working directory."""
import importlib.util
import os
import re
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 1500
REPLY_CAP = 2500
TASK_CAP = 8000
PROMPT_CAP = 15000
MAX_STEPS = 40
HEAD = re.compile(r"^\s*@([A-Za-z_][\w-]*)(?:[ \t]+(.*?))?\s*$")


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply, known):
    """Return (name, arg, body) for the first known action line, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        m = HEAD.match(line)
        if not m or m.group(1) not in known:
            continue
        name, arg = m.group(1), (m.group(2) or "").strip()
        if name == "done":
            return "done", "", ""
        body = []
        for nxt in lines[i + 1:]:
            if nxt.strip() == "@end":
                break
            body.append(nxt)
        return name, arg, "\n".join(body)
    return None


def clip(text, cap):
    if len(text) <= cap:
        return text
    half = cap // 2
    return text[:half] + "\n[... cut ...]\n" + text[-half:]


def build_prompt(task, history, left):
    note = f"\nModel calls left: {left}."
    if left <= 2:
        note += " Few calls remain: write the required output files now and check them before @done."
    head = "TASK.md:\n" + clip(task, TASK_CAP) + "\n\n"
    tail = "\nYour next action (exactly one @sh, @write or @done):"
    budget = PROMPT_CAP - len(head) - len(note) - len(tail) - 60
    kept, used = [], 0
    for entry in reversed(history):
        if used + len(entry) > budget:
            break
        kept.append(entry)
        used += len(entry)
    kept.reverse()
    dropped = len(history) - len(kept)
    mid = f"[{dropped} earlier steps omitted]\n" if dropped else ""
    return head + mid + "".join(kept) + note + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    known = set(tools) | {"done"}
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        try:
            reply = cellapi.brain(system, build_prompt(task, history, left))
        except cellapi.BudgetExhausted:
            break
        action = parse(reply, known)
        if action is None:
            obs = "No action found. Reply with one line: @sh, @write <path>, or @done. Close @sh and @write with @end."
        elif action[0] == "done":
            break
        else:
            name, arg, body = action
            try:
                obs = tools[name].run(arg, body, {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        history.append(
            f"\n--- step {step + 1} ---\n{clip(reply.strip(), REPLY_CAP)}\n--- result ---\n{clip(str(obs), OBS_CAP)}\n"
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())
