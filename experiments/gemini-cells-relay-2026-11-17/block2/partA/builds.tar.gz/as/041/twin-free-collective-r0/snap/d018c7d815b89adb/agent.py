"""Cell harness, v2. Self-contained: loop, prompt, and sh/write tools.

Run with the task folder as cwd. The model is reached only through cellapi.
The first prompt already contains the task folder's documents and example
expected outputs, so the model can write a solver without spending calls on reading.
"""
import os
import subprocess

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000        # chars of tool output shown back to the model
HIST_CAP = 9000       # chars of history kept in each prompt
PREVIEW_CAP = 9000    # chars of pre-read task material in the first prompt
MAX_STEPS = 40


def read_text(path, cap):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            s = f.read()
    except OSError:
        return ""
    if len(s) > cap:
        s = s[:cap] + "\n...[cut]"
    return s


def preview(cwd):
    """Files list plus the contents of documents and example expectations."""
    names = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for name in sorted(files):
            names.append(os.path.relpath(os.path.join(root, name), cwd))
    out = ["FILES IN WORKING DIRECTORY:"] + ["  " + n for n in names[:200]] + [""]
    used = 0
    docs = [n for n in names if n.endswith(".md") and n != "TASK.md"]
    docs += [n for n in names if n.endswith("expected.json")]
    for n in docs:
        if used >= PREVIEW_CAP:
            break
        body = read_text(os.path.join(cwd, n), min(4000, PREVIEW_CAP - used))
        out.append(f"--- {n} ---\n{body}\n")
        used += len(body)
    return "\n".join(out)


def run_sh(cmd, cwd):
    try:
        p = subprocess.run(["bash", "-c", cmd], cwd=cwd, capture_output=True,
                           text=True, timeout=20)
        text = (p.stdout or "") + (p.stderr or "")
        text += f"\n[exit {p.returncode}]"
    except subprocess.TimeoutExpired:
        text = "[timed out after 20 s]"
    if len(text) > OBS_CAP:
        half = OBS_CAP // 2
        text = text[:half] + "\n...[middle cut]...\n" + text[-half:]
    return text


def run_write(path, body, cwd):
    full = os.path.join(cwd, path)
    try:
        d = os.path.dirname(full)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(body)
        return f"[wrote {len(body)} chars to {path}]"
    except OSError as e:
        return f"[write failed: {e}]"


def parse(reply):
    """Return (kind, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s == "@sh" or s.startswith("@sh "):
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return "sh", "", "\n".join(body)
        if s.startswith("@write "):
            path = s[len("@write "):].strip()
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return "write", path, "\n".join(body)
        if s == "@done":
            return "done", "", ""
    return None


def main():
    cwd = os.getcwd()
    with open(os.path.join(HERE, "prompt.md"), encoding="utf-8") as f:
        system = f.read()
    task = read_text(os.path.join(cwd, "TASK.md"), 6000)
    pre = preview(cwd)
    history = []
    for _ in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        hist = "".join(history)
        if len(hist) > HIST_CAP:
            hist = "...[older history cut]\n" + hist[-HIST_CAP:]
        prompt = ("TASK.md:\n" + task + "\n\n" + pre + "\n\nHISTORY:\n" + hist
                  + f"\nModel calls left: {left}. Your next action:")
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        act = parse(reply or "")
        if act is None:
            history.append("\n[your reply had no valid action]\n")
            continue
        kind, arg, body = act
        if kind == "done":
            break
        if kind == "sh":
            out = run_sh(body, cwd)
            history.append(f"\n@sh\n{body}\n@end\n--- output ---\n{out}\n")
        elif kind == "write":
            out = run_write(arg, body, cwd)
            history.append(f"\n@write {arg}\n(content omitted)\n@end\n{out}\n")


if __name__ == "__main__":
    main()
