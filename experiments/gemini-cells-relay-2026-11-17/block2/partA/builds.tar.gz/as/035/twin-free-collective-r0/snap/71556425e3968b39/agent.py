"""Harness for one benchmark episode. Run with the task folder as the working directory.

Changes from the previous version:
- The folder preview is larger, so spec files such as FORMAT.md are shown in full.
- TASK.md budget is slightly larger, and the history gets the remaining prompt space.
- One reply may contain several actions (@sh, @write, @done). They run in order.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2500           # characters of tool output kept per action
REPLY_CAP = 1500         # characters of a model reply kept in the history
PROMPT_CAP = 14000       # user prompt stays under the 16000 character limit
TASK_CAP = 3500          # longest TASK.md shown in full
PREVIEW_CAP = 5500       # total characters of the folder preview
PREVIEW_FILE_CAP = 4500  # files up to this size are shown in full
PREVIEW_HEAD = 1200      # characters shown from larger files
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse_all(reply):
    """Return a list of (tool, arg, body) for every action in the reply, in order."""
    lines = reply.splitlines()
    actions = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                i += 1
                continue
            name = head[0].strip()
            arg = head[1] if len(head) > 1 else ""
            if name == "done":
                actions.append(("done", "", ""))
                i += 1
                continue
            body = []
            j = i + 1
            while j < len(lines) and lines[j].strip() != "@end":
                body.append(lines[j])
                j += 1
            actions.append((name, arg, "\n".join(body)))
            i = j + 1
            continue
        i += 1
    return actions


def clip(text, cap):
    if len(text) <= cap:
        return text
    return text[:cap] + "\n[output cut]"


def preview(cwd):
    """File list plus contents of the small text files in the task folder (TASK.md excluded)."""
    parts = []
    total = 0
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for fn in sorted(files):
            if fn.startswith("."):
                continue
            path = os.path.join(root, fn)
            rel = os.path.relpath(path, cwd)
            if rel == "TASK.md":
                continue
            try:
                size = os.path.getsize(path)
                limit = PREVIEW_FILE_CAP if size <= PREVIEW_FILE_CAP else PREVIEW_HEAD
                with open(path, "rb") as f:
                    raw = f.read(limit)
            except OSError:
                continue
            if b"\0" in raw:
                text = "(binary file)"
            else:
                text = raw.decode("utf-8", "replace")
                if size > len(raw):
                    text += f"\n[... {size - len(raw)} more bytes not shown]"
            block = f"--- {rel} ({size} bytes)\n{text}\n"
            if total + len(block) > PREVIEW_CAP:
                parts.append(f"--- {rel} ({size} bytes) [not shown, preview is full]\n")
                continue
            parts.append(block)
            total += len(block)
    return "".join(parts) if parts else "(no other files)\n"


def build_prompt(task, pre, history, left):
    head = (
        "TASK.md:\n" + clip(task, TASK_CAP) + "\n\n"
        + "FOLDER PREVIEW (read for you at the start, no need to re-read):\n" + pre + "\n"
    )
    tail = f"\nModel calls left: {left}. Your next action:"
    budget = PROMPT_CAP - len(head) - len(tail)
    kept = []
    used = 0
    for entry in reversed(history):
        if used + len(entry) > budget:
            break
        kept.append(entry)
        used += len(entry)
    kept.reverse()
    note = ""
    if len(kept) < len(history):
        note = f"(the first {len(history) - len(kept)} steps were dropped to fit the prompt limit)\n"
    return head + note + "".join(kept) + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    pre = preview(cwd)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, pre, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        actions = parse_all(reply)
        if not actions:
            obs = "Could not read an action. Reply with @tool ... @end blocks or @done."
            done = False
        else:
            results = []
            done = False
            for name, arg, body in actions:
                if name == "done":
                    done = True
                    break
                if name not in tools:
                    results.append(f"[{name}] Unknown tool {name}.")
                    continue
                try:
                    out = tools[name].run(arg, body, {"cwd": cwd})
                except Exception as exc:
                    out = f"Tool error: {type(exc).__name__}: {exc}"
                results.append(f"[{name} {arg}]\n{clip(out, OBS_CAP)}")
            obs = "\n".join(results) if results else "(no action run)"
        obs = clip(obs, OBS_CAP)
        reply_text = clip(reply.strip(), REPLY_CAP)
        history.append(f"\n--- step {step + 1} ---\n{reply_text}\n--- result ---\n{obs}\n")
        if done:
            break


if __name__ == "__main__":
    sys.exit(main())
