"""Harness v4 for cell B. Self-contained: no tools folder needed.

The task folder's spec files (*.md besides TASK.md) and a folder listing are shown in
every prompt, so the model sees the rules from its first call. Prompt size is capped
to stay under the 16000-character limit.
"""
import os
import re
import subprocess
import sys

import cellapi

OBS_CAP = 2500
TASK_CAP = 2500
SPEC_CAP = 7000
LIST_CAP = 600
HIST_CAP = 2500
MAX_STEPS = 40

SYSTEM_LINES = [
    "You are a cell: a model inside a small harness. You work in one folder (your working directory).",
    "Your task is in TASK.md, shown in the prompt. The spec files of the task (FORMAT.md, SPEC.md, ...)",
    "are also shown in the prompt, so you already have the rules. Do not spend a call just to read them.",
    "Solve the task with as few model calls as possible.",
    "",
    "Reply with EXACTLY ONE action and nothing else. Use one of these forms:",
    "",
    "@sh",
    "<shell commands, e.g. python3 solve.py>",
    "@end",
    "",
    "@write <path>",
    "<full file content>",
    "@end",
    "",
    "@done",
    "",
    "Rules:",
    "- Every reply must be one of the forms above. No placeholders, no prose around the action.",
    "- Call 1: write one complete solver script that implements ALL the rules in the spec files,",
    "  writes the required output file, and prints its result next to any example expected output.",
    "- Call 2: run the solver on the example and on the data, check the output file exists with the",
    "  required shape, and fix only what differs.",
    "- Write the required output file early, even if imperfect. A partial answer scores more than none.",
    "- Keep replies short. For long code, write the file with @write in one reply, run it in the next.",
    "- Print results with head -c or sed -n ranges; tool output is cut after about 2500 characters.",
    "- Never repeat a command whose output you have already seen.",
    "- Do not reply @done before the required output file exists.",
]
SYSTEM = "\n".join(SYSTEM_LINES) + "\n"

ACTION = re.compile(r"^\s*@(sh|write|done)\b\s*(.*)$")


def parse(reply):
    """Return (kind, arg, body) for the first well-formed action, or None."""
    lines = reply.replace("```", "").splitlines()
    for i, line in enumerate(lines):
        m = ACTION.match(line)
        if not m:
            continue
        kind, arg = m.group(1), m.group(2).strip()
        if kind == "done":
            return "done", "", ""
        body = []
        for nxt in lines[i + 1:]:
            if nxt.strip() == "@end":
                break
            body.append(nxt)
        return kind, arg, "\n".join(body)
    return None


def run_sh(body, cwd):
    try:
        p = subprocess.run(["bash", "-c", body], cwd=cwd, capture_output=True,
                           text=True, timeout=18)
        out = (p.stdout or "") + (p.stderr or "")
        return out if out.strip() else "[exit %d, no output]" % p.returncode
    except subprocess.TimeoutExpired:
        return "[timed out after 18 s]"


def run_write(path, body, cwd):
    if not path:
        return "write needs a path: @write <path>"
    full = os.path.join(cwd, path)
    os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(body)
    return "wrote %s (%d chars)" % (path, len(body))


def read_specs(cwd):
    """Concatenate the *.md spec files of the task folder (not TASK.md), capped."""
    parts = []
    for name in sorted(os.listdir(cwd)):
        path = os.path.join(cwd, name)
        if name.endswith(".md") and name != "TASK.md" and os.path.isfile(path):
            try:
                with open(path, encoding="utf-8", errors="replace") as f:
                    parts.append("== " + name + " ==\n" + f.read())
            except OSError:
                pass
    text = "\n".join(parts)
    if len(text) > SPEC_CAP:
        text = text[:SPEC_CAP] + "\n[specs cut]"
    return text


def listing(cwd):
    """Short list of files in the task folder, so the model knows where the data is."""
    out = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        rel = os.path.relpath(root, cwd)
        for f in sorted(files):
            out.append(os.path.normpath(os.path.join(rel, f)))
    text = "\n".join(out)
    if len(text) > LIST_CAP:
        text = text[:LIST_CAP] + "\n[list cut]"
    return text


def main():
    cwd = os.getcwd()
    with open(os.path.join(cwd, "TASK.md"), encoding="utf-8") as f:
        task = f.read()
    if len(task) > TASK_CAP:
        task = task[:TASK_CAP] + "\n[task cut]"
    specs = read_specs(cwd)
    files = listing(cwd)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        hist = "".join(history)
        if len(hist) > HIST_CAP:
            hist = "[older steps cut]\n" + hist[-HIST_CAP:]
        prompt = ("TASK.md:\n" + task + "\n\n"
                  + ("SPEC FILES:\n" + specs + "\n\n" if specs else "")
                  + "FILES IN FOLDER:\n" + files + "\n\n"
                  + hist
                  + "\nModel calls left: %d. Your next action:" % left)
        try:
            reply = cellapi.brain(SYSTEM, prompt)
        except Exception:
            break
        reply = reply or ""
        action = parse(reply)
        if action is None:
            obs = ("Could not read an action. Reply with exactly one of: "
                   "@sh ... @end, @write <path> ... @end, or @done.")
        elif action[0] == "done":
            break
        elif action[0] == "sh":
            obs = run_sh(action[2], cwd)
        else:
            obs = run_write(action[1], action[2], cwd)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append("\n--- step %d ---\n%s\n--- result ---\n%s\n"
                       % (step + 1, reply.strip(), obs))


if __name__ == "__main__":
    sys.exit(main())
