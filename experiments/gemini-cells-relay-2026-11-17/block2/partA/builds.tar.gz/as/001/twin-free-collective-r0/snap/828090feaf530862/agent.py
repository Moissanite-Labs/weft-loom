"""Harness for a cell. Run with the task folder as working directory.

The model is reached only through cellapi.brain(system, prompt) and cellapi.calls_left().
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000        # max characters of one tool output kept in history
PROMPT_CAP = 13000    # keep each prompt well under the referee's 16000-character limit
SHRINK_TO = 250       # older results are squeezed to this size when the prompt is too long
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def render(task, entries, footer):
    parts = ["TASK.md:\n" + task + "\n"]
    for i, (reply, obs) in enumerate(entries):
        parts.append(f"\n--- step {i + 1} ---\n{reply}\n--- result ---\n{obs}\n")
    parts.append(footer)
    return "".join(parts)


def fit(task, entries, footer):
    """Build the prompt; if it is too long, squeeze the oldest entries first."""
    text = render(task, entries, footer)
    for i in range(len(entries)):
        if len(text) <= PROMPT_CAP:
            break
        reply, obs = entries[i]
        if len(obs) > SHRINK_TO:
            entries[i] = (reply[:SHRINK_TO] + " [cut]", obs[:SHRINK_TO] + "\n[older output cut]")
        text = render(task, entries, footer)
    for i in range(len(entries)):
        if len(text) <= PROMPT_CAP:
            break
        reply, obs = entries[i]
        entries[i] = (reply[:80] + " [cut]", obs[:80] + " [cut]")
        text = render(task, entries, footer)
    if len(text) > PROMPT_CAP:
        text = text[:PROMPT_CAP - len(footer)] + footer
    return text


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    entries = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        footer = (f"\nModel calls left: {left}. Reply with exactly one action. "
                  "Put all the work for this step into one @sh block. Your next action:")
        prompt = fit(task, entries, footer)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        except Exception as exc:
            entries.append(("(model error)", f"{type(exc).__name__}: {exc}"))
            break
        action = parse(reply or "")
        if action is None:
            obs = "Could not read an action. Use exactly the @tool ... @end form, or @done."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}. Known tools: {', '.join(tools)}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        entries.append(((reply or "").strip(), obs))


if __name__ == "__main__":
    sys.exit(main())
