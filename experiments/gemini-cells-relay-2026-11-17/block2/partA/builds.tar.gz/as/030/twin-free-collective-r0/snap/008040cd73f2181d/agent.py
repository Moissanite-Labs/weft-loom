"""Cell harness v2: full rule files in the prompt, robust parsing, trimmed observations."""
import os
import subprocess

import cellapi

ROOT = os.getcwd()
PROMPT_CAP = 14000
OBS_CAP = 2200
DOC_CAP = 6500
MAX_CALLS = 3

SYSTEM = """You are a careful engineer working in a task folder through a shell. Each reply is exactly ONE action:
  @sh            then shell lines, closed by a line containing only @end   (bash in the folder, 20 s limit)
  @write <path>  then file content, closed by a line containing only @end
  @done          when the output file is written and checked
Replies without an action waste a call. You have about 3 calls in total.

Plan:
- The first action must be COMPLETE: one @sh that writes a full Python solver with a quoted heredoc
  (cat > solve.py <<'PYEOF' ... PYEOF), runs it, writes the required output file in the exact format,
  prints it, and compares it with any expected.json in an example folder.
- Apply every rule literally and in the stated order: delimiters, quoting, timestamp pattern (compare as
  points in time), clock offsets, decimal marks, negative styles, decorations, status filters, window end
  inclusivity, continuation lines, level names, rounding. Do not guess a parameter; read it.
- Bugfix tasks: fix the code so the whole SPEC contract holds, including edge cases, then run the tests.
- If a run printed a Traceback or a mismatch, fix the solver in the next action and rerun.
- Reply @done only after the output file is written and checked."""


def read(path, limit=None):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception as e:
        return "[unreadable: %s]" % e
    if limit is not None and len(text) > limit:
        text = text[:limit] + "\n[...cut]"
    return text


def walk_files():
    found = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = sorted(d for d in dirnames if d not in ("__pycache__", ".git"))
        for name in sorted(filenames):
            found.append(os.path.relpath(os.path.join(dirpath, name), ROOT))
    return found


def rule_docs(files):
    names = [f for f in files if f.endswith(".md")]
    names.sort(key=lambda f: (f != "TASK.md", f))
    out, used = [], 0
    for name in names:
        room = DOC_CAP - used
        if room < 300:
            break
        body = read(os.path.join(ROOT, name), limit=room)
        out.append("--- %s ---\n%s" % (name, body))
        used += len(body)
    return "\n\n".join(out)


def samples(files):
    data = [f for f in files if not f.endswith(".md") and "/data/" in ("/" + f)][:8]
    out = []
    for name in data:
        try:
            with open(os.path.join(ROOT, name), encoding="utf-8", errors="replace") as f:
                lines = [(next(f, "") or "").rstrip("\n")[:160] for _ in range(4)]
        except Exception as e:
            lines = ["[unreadable: %s]" % e]
        out.append("--- %s (first lines) ---\n%s" % (name, "\n".join(l for l in lines if l)))
    return "\n".join(out)


def clip(text):
    if len(text) <= OBS_CAP:
        return text
    half = OBS_CAP // 2
    return text[:half] + "\n[...]\n" + text[-half:]


def run_sh(cmd):
    try:
        r = subprocess.run(["bash", "-c", cmd], cwd=ROOT, capture_output=True,
                           text=True, timeout=18)
        out = r.stdout or ""
        if r.stderr:
            out += "\n[stderr]\n" + r.stderr
        out += "\n[exit %d]" % r.returncode
        return clip(out)
    except subprocess.TimeoutExpired:
        return "[timeout after 18 s]"
    except Exception as e:
        return "[shell error: %s]" % e


def run_write(path, body):
    full = os.path.normpath(os.path.join(ROOT, path))
    if not (full == ROOT or full.startswith(ROOT + os.sep)):
        return "[refused: path outside the task folder]"
    try:
        d = os.path.dirname(full)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(body)
        return "wrote %s (%d chars)" % (path, len(body))
    except Exception as e:
        return "[write error: %s]" % e


def parse_first(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s == "@done":
            return ("done", None)
        if s == "@sh" or s.startswith("@sh "):
            kind, path = "sh", None
        elif s.startswith("@write"):
            kind, path = "write", s[len("@write"):].strip()
        else:
            continue
        body = []
        for l in lines[i + 1:]:
            if l.strip() == "@end":
                break
            body.append(l)
        data = "\n".join(body) if kind == "sh" else (path, "\n".join(body))
        return (kind, data)
    return None


def calls_remaining(used):
    try:
        return int(cellapi.calls_left())
    except Exception:
        return MAX_CALLS - used


def build_prompt(base, observations, left):
    while True:
        tail = ""
        if observations:
            tail = "\n\n=== Your earlier actions and their results ===\n" + "\n".join(observations)
        text = base + tail + "\n\nModel calls left: %d. Your next action:" % left
        if len(text) <= PROMPT_CAP or not observations:
            break
        observations = observations[1:]
    if len(text) > PROMPT_CAP:
        text = base[:PROMPT_CAP - 200] + "\nModel calls left: %d. Your next action:" % left
    return text


def main():
    files = walk_files()
    base = ("=== Task folder rules ===\n" + rule_docs(files) +
            "\n\n=== Files ===\n" + "\n".join(files[:80]) +
            "\n\n=== Data samples ===\n" + samples(files) +
            "\n\nFirst action: a complete @sh that writes, runs and checks the solver.")
    if len(base) > PROMPT_CAP - 2500:
        base = base[:PROMPT_CAP - 2500]

    observations = []
    used = 0
    while used < MAX_CALLS:
        left = calls_remaining(used)
        if left <= 0:
            break
        prompt = build_prompt(base, observations, left)
        try:
            reply = cellapi.brain(SYSTEM, prompt)
        except Exception as e:
            observations.append("[model error: %s]" % e)
            break
        used += 1
        act = parse_first(reply or "")
        if act is None:
            observations.append("[no action found in reply; reply with exactly one action]")
            continue
        kind, data = act
        if kind == "done":
            break
        if kind == "sh":
            observations.append("ACTION @sh\n" + run_sh(data))
        else:
            path, body = data
            observations.append("ACTION @write " + path + "\n" + run_write(path, body))


if __name__ == "__main__":
    main()
