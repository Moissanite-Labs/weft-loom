"""Harness for a cell. Run with the task folder as the working directory.

The model is reached through cellapi, which the referee provides.
"""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 4000       # characters of tool output shown back to the model (head and tail kept)
REPLY_CAP = 3000     # characters of the model's own reply kept in history
TASK_CAP = 6000      # characters of TASK.md shown in each prompt
PROMPT_CAP = 14000   # keep each prompt under the referee's 16000-character limit
MAX_STEPS = 40       # the referee's call cap usually ends the episode first


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def clip(text, cap):
    """Keep the head and the tail of a long text, so both the start and the end stay visible."""
    if len(text) <= cap:
        return text
    half = cap // 2
    return text[:half] + "\n...[%d chars cut]...\n" % (len(text) - cap) + text[-half:]


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        head = "TASK.md:\n" + clip(task, TASK_CAP) + "\n\n"
        tail = f"\nModel calls left: {left}. Your next action:"
        hist = "".join(history)
        room = PROMPT_CAP - len(head) - len(tail)
        if len(hist) > room:
            hist = "...(earlier steps cut)...\n" + hist[-max(room - 40, 0):]
        prompt = head + hist + tail
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        reply = reply or ""
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Reply with exactly one @tool ... @end block, or @done."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}. Available: {', '.join(tools)}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as e:
                obs = f"Tool error: {e}"
        obs = clip(str(obs), OBS_CAP)
        history.append(f"\n[step {step + 1}] your reply:\n{clip(reply, REPLY_CAP)}\nresult:\n{obs}\n")


if __name__ == "__main__":
    main()
