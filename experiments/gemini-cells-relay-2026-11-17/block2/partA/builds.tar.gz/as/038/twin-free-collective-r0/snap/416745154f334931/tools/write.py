"""Write tool: creates or overwrites a file under the task folder."""
import os

NAME = "write"
HELP = "@write <path>\n<file content>\n@end   -- create or overwrite a file (path relative to the task folder)"


def run(arg, body, ctx):
    path = arg.strip()
    if not path:
        return "No path given. Use: @write <path>"
    root = os.path.realpath(ctx["cwd"])
    full = os.path.realpath(os.path.join(root, path))
    if full != root and not full.startswith(root + os.sep):
        return "Refused: path is outside the task folder."
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(body + ("\n" if body and not body.endswith("\n") else ""))
    return f"wrote {path} ({len(body)} chars)"
