"""Harness for a cell. Loop, prompt budget and output handling.

Run with the task folder as the working directory. The model is reached through cellapi.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_HEAD = 2200
OBS_TAIL = 800
REPLY_CAP = 1500
PROMPT_BUDGET = 15000
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def shorten_obs(obs):
    if len(obs) <= OBS_HEAD + OBS_TAIL:
        return obs
    return obs[:OBS_HEAD] + "\n[... middle cut ...]\n" + obs[-OBS_TAIL:]


def build_prompt(task, history, left, fixed_len):
    """Keep the newest history entries that fit the budget; always keep the task."""
    tail = f"\nModel calls left: {left}. Your next action:"
    room = PROMPT_BUDGET - fixed_len - len("TASK.md:\n") - len(task) - len(tail) - 200
    kept = []
    used = 0
    for entry in reversed(history):
        if used + len(entry) > room:
            break
        kept.append(entry)
        used += len(entry)
    kept.reverse()
    note = ""
    if len(kept) < len(history):
        note = f"\n[{len(history) - len(kept)} older steps dropped to fit the prompt limit]\n"
    return "TASK.md:\n" + task + "\n" + note + "".join(kept) + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left, len(system))
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form, one action per reply."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}. Available: {', '.join(sorted(tools))}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = shorten_obs(str(obs))
        shown = reply.strip()
        if len(shown) > REPLY_CAP:
            shown = shown[:REPLY_CAP] + "\n[reply cut]"
        history.append(f"\n--- step {step + 1} ---\n{shown}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
