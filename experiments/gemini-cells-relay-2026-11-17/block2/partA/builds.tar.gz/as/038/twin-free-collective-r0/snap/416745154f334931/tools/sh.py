"""Shell tool: runs the body in bash inside the task folder."""
import subprocess

NAME = "sh"
HELP = "@sh\n<shell commands>\n@end   -- run shell commands in the task folder (20 s limit)"


def run(arg, body, ctx):
    try:
        p = subprocess.run(
            ["bash", "-c", body],
            cwd=ctx["cwd"],
            capture_output=True,
            text=True,
            timeout=20,
        )
    except subprocess.TimeoutExpired:
        return "Timed out after 20 s."
    out = (p.stdout or "") + (p.stderr or "")
    if not out.strip():
        return f"(no output, exit code {p.returncode})"
    return out
