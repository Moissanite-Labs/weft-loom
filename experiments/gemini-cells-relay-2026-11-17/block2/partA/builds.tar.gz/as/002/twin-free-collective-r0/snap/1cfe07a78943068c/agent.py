"""Harness for a cell. Run with the task folder as the working directory.

Changes from the seed: larger observations (head and tail kept), a prompt budget that
stays under the referee's per-prompt limit, a tolerant action parser, and no crash when
the model call fails.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3500       # characters of tool output shown back to the model
PROMPT_CAP = 14000   # stay under the referee's 16000-character prompt limit
TASK_CAP = 6000      # longest TASK.md text shown in full
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def clip(text, cap):
    """Keep the head and the tail of long text so both the start and the end stay visible."""
    if len(text) <= cap:
        return text
    keep = cap // 2
    return text[:keep] + "\n[... output cut ...]\n" + text[-keep:]


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("@") and not s.startswith("@end"):
            head = s[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def build_prompt(task, history, left):
    tail = f"\nModel calls left: {left}. Your next action:"
    base = "TASK.md:\n" + clip(task, TASK_CAP) + "\n\n"
    budget = PROMPT_CAP - len(base) - len(tail) - 120
    kept, total = [], 0
    for h in reversed(history):
        if total + len(h) > budget:
            break
        kept.append(h)
        total += len(h)
    kept.reverse()
    note = ""
    dropped = len(history) - len(kept)
    if dropped:
        note = f"\n[{dropped} earlier step(s) omitted to fit the prompt]\n"
    return base + note + "".join(kept) + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        except Exception as exc:
            history.append(f"\n--- step {step + 1} ---\n(model call failed: {type(exc).__name__})\n")
            continue
        action = parse(reply or "")
        if action is None:
            obs = ("Could not read an action. Reply with exactly one block, e.g.\n"
                   "@sh\n<commands>\n@end\n\nor @write <path> ... @end, or @done.")
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}. Known tools: {', '.join(sorted(tools))}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = clip(str(obs), OBS_CAP)
        history.append(f"\n--- step {step + 1} ---\n{(reply or '').strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
