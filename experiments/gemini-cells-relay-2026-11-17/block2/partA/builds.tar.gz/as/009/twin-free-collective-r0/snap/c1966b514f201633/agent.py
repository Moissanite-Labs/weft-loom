"""Cell harness, revision 2.

One action per model reply: @sh ... @end, @write <path> ... @end, or @done.
Run with the task folder as the working directory.
"""
import os
import subprocess

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 5000
REPLY_CAP = 1500
PROMPT_CAP = 15000
MAX_STEPS = 12


def clip(text, cap=OBS_CAP):
    if len(text) <= cap:
        return text
    head = cap * 2 // 3
    tail = cap - head
    return text[:head] + f"\n...[{len(text) - cap} chars cut]...\n" + text[-tail:]


def _body(lines, start):
    body = []
    for nxt in lines[start:]:
        if nxt.strip() == "@end":
            break
        body.append(nxt)
    return "\n".join(body)


def parse(reply):
    lines = reply.splitlines()
    for i, raw in enumerate(lines):
        line = raw.strip().strip("`").strip()
        if line == "@done":
            return "done", "", ""
        if line == "@sh" or line.startswith("@sh "):
            return "sh", "", _body(lines, i + 1)
        if line.startswith("@write"):
            path = line[len("@write"):].strip().strip("`\"'")
            return "write", path, _body(lines, i + 1)
    return None


def run_sh(cmd, cwd):
    try:
        p = subprocess.run(["bash", "-c", cmd], cwd=cwd, capture_output=True,
                           text=True, timeout=20)
        out = p.stdout or ""
        if p.stderr:
            out += "\n[stderr]\n" + p.stderr
        out += f"\n[exit {p.returncode}]"
    except subprocess.TimeoutExpired:
        out = "[timed out after 20 s; output dropped. Make the command faster.]"
    return clip(out)


def write_file(rel, body, cwd):
    if not rel:
        return "No path given to @write. Use: @write <path>"
    path = os.path.join(cwd, rel)
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, "w") as f:
        f.write(body + "\n")
    return f"Wrote {len(body)} chars to {rel}."


def build_prompt(task, history, left, system):
    head = "TASK.md:\n" + clip(task, PROMPT_CAP // 2) + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    room = PROMPT_CAP - len(system) - len(head) - len(tail) - 200
    chunks = []
    for reply, obs in reversed(history):
        chunk = f"Your reply:\n{reply}\nResult:\n{obs}\n\n"
        if len(chunk) > room:
            break
        chunks.append(chunk)
        room -= len(chunk)
    return head + "".join(reversed(chunks)) + tail


def main():
    cwd = os.getcwd()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read()
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for _ in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left, system)
        try:
            reply = cellapi.brain(system, prompt) or ""
        except cellapi.BudgetExhausted:
            break
        except Exception as e:
            history.append(("", f"Model call failed: {e}"))
            break
        action = parse(reply)
        if action is None:
            history.append((clip(reply, REPLY_CAP),
                            "No action found. Reply with exactly one @sh, @write or @done block."))
            continue
        kind, arg, body = action
        if kind == "done":
            break
        if kind == "sh":
            obs = run_sh(body, cwd)
        else:
            obs = write_file(arg, body, cwd)
        history.append((clip(reply, REPLY_CAP), obs))
    return 0


main()
