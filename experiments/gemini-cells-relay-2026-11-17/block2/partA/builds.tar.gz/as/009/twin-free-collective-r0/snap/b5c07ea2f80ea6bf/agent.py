"""Improved seed harness (cell A)."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2400
REPLY_CAP = 2000
TASK_CAP = 5000
PROMPT_CAP = 14000
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("@") and not s.startswith("@end"):
            head = s[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def build_prompt(task, history, left):
    head = "TASK.md:\n" + task + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    budget = PROMPT_CAP - len(head) - len(tail) - 200
    kept, used = [], 0
    for item in reversed(history):
        if used + len(item) > budget:
            break
        kept.append(item)
        used += len(item)
    kept.reverse()
    note = ""
    if len(kept) < len(history):
        note = f"\n[{len(history) - len(kept)} earlier step(s) not shown]\n"
    return head + note + "".join(kept) + tail


def cut(text):
    if len(text) <= OBS_CAP:
        return text
    half = OBS_CAP // 2
    return text[:half] + "\n[... output cut ...]\n" + text[-half:]


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()[:TASK_CAP]
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Reply with one @sh ... @end, @write <path> ... @end, or @done."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}. Available: {', '.join(sorted(tools))}, done."
        else:
            try:
                obs = str(tools[action[0]].run(action[1], action[2], {"cwd": cwd}))
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        shown = reply.strip()
        if len(shown) > REPLY_CAP:
            shown = shown[:REPLY_CAP] + "\n[reply cut]"
        history.append(f"\n--- step {step + 1} ---\n{shown}\n--- result ---\n{cut(obs)}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
