"""Harness for cell A. Builder version: turn 6 (cell B)."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2500
MAX_STEPS = 40
PROMPT_BUDGET = 15000
FILES_BUDGET = 8000
PER_FILE_CAP = 3000

EXTRA = """
Working rules:
- The files of your folder are listed in the prompt (long ones are cut). Do not spend a call re-reading them.
- Each reply is one action. Write the complete solution in one @write, run it in the next reply, then fix only what the run shows.
- If the task has an example with an expected answer, run the solver on it first and compare.
- Use exact arithmetic (Decimal) for money and follow the rounding rule in the spec.
- Rules files (FORMAT.md, spec, README) may be cut in the listing: cat them in full before coding, and apply the rules in the order given.
- Write the required output file before your calls run out. A missing output scores zero.
"""


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def read_files(cwd):
    found = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for name in sorted(files):
            if name.startswith(".") or name == "TASK.md":
                continue
            path = os.path.join(root, name)
            rel = os.path.relpath(path, cwd)
            found.append((("data" in rel.split(os.sep)), rel, path))
    found.sort()
    out = []
    used = 0
    for _, rel, path in found:
        try:
            with open(path, encoding="utf-8") as f:
                text = f.read()
        except Exception:
            continue
        size = os.path.getsize(path)
        room = FILES_BUDGET - used
        if room < 200:
            out.append(f"=== {rel} ({size} bytes): not shown, out of room ===\n")
            continue
        cap = min(PER_FILE_CAP, room)
        note = "" if len(text) <= cap else f"\n[file cut: showing {cap} of {len(text)} chars]"
        block = f"=== {rel} ({size} bytes) ===\n{text[:cap]}{note}\n"
        out.append(block)
        used += len(block)
    return "".join(out)


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + EXTRA + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    files = read_files(cwd)
    head = ("TASK.md:\n" + task + "\n\nFILES IN YOUR FOLDER (already shown, no need to re-read):\n"
            + files)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        tail = f"\nModel calls left: {left}. Your next action:"
        while history and len(head) + sum(len(h) for h in history) + len(tail) > PROMPT_BUDGET:
            history.pop(0)
        prompt = head + "".join(history) + tail
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
