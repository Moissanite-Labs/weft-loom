"""Harness for a cell: loop, prompt and tools."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2500
REPLY_CAP = 1200
DOC_CAP = 4000
PROMPT_CAP = 15000
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def listing(cwd, limit=60):
    out = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        rel = os.path.relpath(root, cwd)
        depth = 0 if rel == "." else rel.count(os.sep) + 1
        if depth > 2:
            dirs[:] = []
            continue
        for f in sorted(files):
            out.append(os.path.relpath(os.path.join(root, f), cwd))
            if len(out) >= limit:
                return "\n".join(out) + "\n..."
    return "\n".join(out)


def docs(cwd):
    parts = []
    for name in sorted(os.listdir(cwd)):
        path = os.path.join(cwd, name)
        if name.endswith(".md") and name != "TASK.md" and os.path.isfile(path):
            with open(path, encoding="utf-8", errors="replace") as f:
                text = f.read()
            if len(text) > DOC_CAP:
                text = text[:DOC_CAP] + "\n[doc cut: use sed -n to read the rest]"
            parts.append(f"--- {name} (preloaded) ---\n{text}\n")
    return "".join(parts)


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    preload = "Files in your folder:\n" + listing(cwd) + "\n\n" + docs(cwd)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        head = "TASK.md:\n" + task + "\n\n" + preload + "\n"
        tail = f"\nModel calls left: {left}. Your next action:"
        hist = list(history)
        while hist and len(head) + sum(map(len, hist)) + len(tail) > PROMPT_CAP:
            hist.pop(0)
        prompt = head + "".join(hist) + tail
        if len(prompt) > PROMPT_CAP:
            prompt = prompt[:PROMPT_CAP - len(tail)] + tail
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()[:REPLY_CAP]}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
