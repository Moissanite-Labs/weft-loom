"""Harness for a cell. The loop, the prompt and the tools.

Run with the task folder as the working directory. The model is reached through cellapi.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000        # characters of tool output shown back to the model
REPLY_CAP = 2500      # characters of a model reply kept in history
PROMPT_CHARS = 11000  # leaves room for the system prompt under the 16000-character limit
FIXED_CAP = 8000      # hard cap on the up-front block (task + listing + specs)
MAX_STEPS = 40
MD_CAP = 2500         # characters of each spec file shown up front
TASK_CAP = 4000       # characters of TASK.md shown up front


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def overview(cwd):
    """Up-front context: the task, a file listing, and the spec files, so no call is spent looking."""
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()[:TASK_CAP]
    files = []
    for root, dirs, names in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for n in sorted(names):
            files.append(os.path.relpath(os.path.join(root, n), cwd))
    listing = "\n".join(files[:60])
    specs = []
    for p in files:
        if p.endswith((".md", ".txt", ".json")) and p != "TASK.md" and len(specs) < 4:
            try:
                with open(os.path.join(cwd, p), errors="replace") as f:
                    specs.append(f"== {p}\n" + f.read()[:MD_CAP])
            except OSError:
                pass
    ctx = "Files in the task folder:\n" + listing + "\n\n" + "\n\n".join(specs)
    return task, ctx


def build_prompt(task, ctx, history, left):
    fixed = "TASK.md:\n" + task + "\n\n" + ctx + "\n\n"
    if len(fixed) > FIXED_CAP:
        fixed = fixed[:FIXED_CAP] + "\n[context cut]\n\n"
    note = f"\nModel calls left: {left}."
    if left <= 1:
        note += " This is your LAST call: make sure the required output file is written now."
    note += " Your next action:"
    budget = PROMPT_CHARS - len(fixed) - len(note) - 40
    kept, used = [], 0
    for h in reversed(history):
        if used + len(h) > budget:
            break
        kept.append(h)
        used += len(h)
    kept.reverse()
    dropped = len(history) - len(kept)
    prefix = "[%d earlier steps omitted]\n" % dropped if dropped else ""
    return fixed + prefix + "".join(kept) + note


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    task, ctx = overview(cwd)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, ctx, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        except Exception:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}. Available: {', '.join(sorted(tools))}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = str(obs)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        shown = reply.strip()
        if len(shown) > REPLY_CAP:
            shown = shown[:REPLY_CAP] + "\n[reply cut]"
        history.append(f"\n--- step {step + 1} ---\n{shown}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
