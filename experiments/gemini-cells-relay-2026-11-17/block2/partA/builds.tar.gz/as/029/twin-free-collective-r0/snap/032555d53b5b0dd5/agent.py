"""Harness for a cell: loop, prompt budget, tools. Run with the task folder as cwd."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 4000
REPLY_CAP = 1500
TASK_CAP = 6000
PROMPT_CAP = 14000
MAX_STEPS = 40


def clip(text, cap):
    text = str(text)
    if len(text) <= cap:
        return text
    head = (cap * 2) // 3
    tail = cap - head - 120
    cut = len(text) - head - tail
    return (text[:head]
            + f"\n[... {cut} chars cut here. Read the rest in pieces: head -c 3000 FILE, "
              f"or tail -c +3001 FILE | head -c 3000 ...]\n"
            + text[-tail:])


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = clip(f.read(), TASK_CAP)
    budget = PROMPT_CAP - len(system) - len(task) - 300
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        hist = "".join(history)
        if len(hist) > budget:
            hist = "[earlier steps dropped to fit the prompt]\n" + hist[-max(0, budget - 60):]
        prompt = "TASK.md:\n" + task + "\n\n" + hist + f"\nModel calls left: {left}. Your next action:"
        reply = cellapi.brain(system, prompt) or ""
        action = parse(reply)
        if action is None:
            history.append(f"\n--- step {step + 1} ---\n{clip(reply.strip(), REPLY_CAP)}\n"
                           "--- result ---\nNo action found. Reply with one @sh ... @end or @write ... @end block.\n")
            continue
        name, arg, body = action
        if name == "done":
            break
        if name not in tools:
            obs = f"Unknown action @{name}. Use one of: {', '.join(sorted(tools))}."
        else:
            try:
                obs = tools[name].run(arg, body, {"cwd": cwd})
            except Exception as e:
                obs = f"tool error: {type(e).__name__}: {e}"
        history.append(f"\n--- step {step + 1} ---\n{clip(reply.strip(), REPLY_CAP)}\n"
                       f"--- result ---\n{clip(obs, OBS_CAP)}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
