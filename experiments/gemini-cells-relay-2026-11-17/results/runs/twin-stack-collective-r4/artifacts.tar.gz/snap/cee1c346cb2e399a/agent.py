"""Harness: task folder shown up front, several actions per reply."""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2500
REPLY_KEEP = 1500
MAX_STEPS = 40
PROMPT_CAP = 14500
FILES_CAP = 6500
FILE_CAP = 3000


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse_all(reply):
    actions = []
    lines = reply.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line.startswith("@") or line.startswith("@end"):
            i += 1
            continue
        name = line[1:].split(" ")[0]
        arg = line[1 + len(name):].strip()
        i += 1
        if name == "done":
            actions.append(("done", "", ""))
            break
        body = []
        while i < len(lines) and lines[i].strip() != "@end":
            body.append(lines[i])
            i += 1
        i += 1
        actions.append((name, arg, "\n".join(body)))
    return actions


def task_files(cwd):
    out = []
    budget = FILES_CAP
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for fn in sorted(files):
            path = os.path.join(root, fn)
            rel = os.path.relpath(path, cwd)
            if rel == "TASK.md":
                continue
            if budget <= 0:
                out.append(f"== {rel} (not shown: budget used up)")
                continue
            try:
                with open(path, encoding="utf-8") as f:
                    text = f.read(min(budget, FILE_CAP))
            except Exception:
                out.append(f"== {rel} (binary or unreadable)")
                continue
            budget -= len(text)
            out.append(f"== {rel}\n{text}")
    return "\n".join(out)


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    files = task_files(cwd)
    head = ("TASK.md:\n" + task + "\n\nFILES IN YOUR FOLDER (shown up front, no need to cat them):\n"
            + files + "\n\n")
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        tail = f"\nModel calls left: {left}. Your next action:"
        hist = list(history)
        while hist and len(system) + len(head) + sum(len(h) for h in hist) + len(tail) > PROMPT_CAP:
            hist.pop(0)
        prompt = head + "".join(hist) + tail
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        actions = parse_all(reply)
        if not actions:
            history.append("\nOBSERVATION:\nCould not read an action. Use the @tool ... @end form.\n")
            continue
        obs_parts = []
        done = False
        for name, arg, body in actions:
            if name == "done":
                done = True
                break
            if name not in tools:
                obs_parts.append(f"Unknown tool {name}.")
                continue
            try:
                out = tools[name].run(arg, body, {"cwd": cwd})
            except Exception as e:
                out = f"tool error: {e}"
            obs_parts.append(f"[{name} {arg}] {out}")
        if done:
            break
        obs = "\n".join(obs_parts)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n...(cut)"
        history.append("\nYOUR REPLY:\n" + reply[:REPLY_KEEP] + "\nOBSERVATION:\n" + obs + "\n")


if __name__ == "__main__":
    main()
