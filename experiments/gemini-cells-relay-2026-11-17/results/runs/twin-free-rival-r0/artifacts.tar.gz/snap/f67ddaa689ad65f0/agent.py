"""Harness v8 (cell B): spec and pkg sources preloaded, one action per call, bounded loop.
Run with the task folder as working directory."""
import glob
import os
import re
import subprocess

import cellapi

CWD = os.getcwd()
AT = "@"
SH = AT + "sh"
WR = AT + "write"
DN = AT + "done"
END = AT + "end"
OBS_CAP = 1500
PROMPT_CAP = 14000
MAX_STEPS = 12
SPEC_BUDGET = 6000
SRC_BUDGET = 3500
SPEC_PATTERNS = ["TASK.md", "FORMAT.md", "SPEC.md", "*/TASK.md", "*/FORMAT.md", "*/SPEC.md"]
SRC_PATTERNS = ["pkg/*.py", "*.py"]
HDR = re.compile(r"^\s*@(sh|write|done)\b\s*(.*)$")

SYSTEM = "\n".join([
    "You are a cell working in a task folder through a text protocol.",
    "Each reply contains exactly ONE action and nothing else, in one of these forms:",
    "",
    SH,
    "<shell commands, run in the task folder>",
    END,
    "",
    WR + " <relative/path>",
    "<file content>",
    END,
    "",
    DN,
    "",
    "Rules: the spec files and pkg/*.py sources are in the prompt; read them fully first.",
    "Model calls are scarce: combine work into one action.",
    "Bugfix tasks: check each module against its SPEC contract, not only the examples "
    "(empty input, single element, equal values, repeated items, target below or above all items, "
    "last element, touching intervals, multi-digit numbers, numeric not string comparison, never raising). "
    "Fix all modules in one action with quoted heredocs and run a python3 check of the examples and edge cases.",
    "Ledger and logwin tasks: read FORMAT.md fully, run the solver on example/ and compare with expected.json, "
    "then run it on data/. Report rejected rows with count and sample per reason; never drop rows silently. "
    "Always write the required output file.",
    "Reply with " + DN + " only when the required output is written and verified.",
])


def find_files(patterns):
    out = []
    for pat in patterns:
        for p in sorted(glob.glob(os.path.join(CWD, pat))):
            if p not in out:
                out.append(p)
    return out


def gather(patterns, budget):
    chunks = []
    used = 0
    for path in find_files(patterns):
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                body = f.read()
        except OSError:
            continue
        piece = "== " + os.path.relpath(path, CWD) + " ==\n" + body + "\n"
        room = budget - used
        if room <= 0:
            break
        piece = piece[:room]
        chunks.append(piece)
        used += len(piece)
    return "".join(chunks)


def build_prompt(history, left):
    fixed = "Model calls left: %d\n\n" % left + gather(SPEC_PATTERNS, SPEC_BUDGET) + gather(SRC_PATTERNS, SRC_BUDGET)
    room = PROMPT_CAP - len(fixed) - len(SYSTEM) - 200
    tail = []
    total = 0
    for act, obs in reversed(history):
        part = "--- your action ---\n" + act + "\n--- result ---\n" + obs + "\n"
        if total + len(part) > room:
            break
        tail.append(part)
        total += len(part)
    tail.reverse()
    return fixed + "".join(tail) + "\nYour next action:"


def parse(reply):
    lines = reply.replace("\r", "").split("\n")
    for i, line in enumerate(lines):
        m = HDR.match(line)
        if not m:
            continue
        kind, arg = m.group(1), m.group(2).strip()
        if kind == "done":
            return ("done", "", "")
        body = []
        for ln in lines[i + 1:]:
            if ln.strip() == END:
                break
            body.append(ln)
        return (kind, arg, "\n".join(body))
    return None


def run_sh(cmd):
    try:
        p = subprocess.run(["bash", "-c", cmd], cwd=CWD, capture_output=True, text=True, timeout=60)
        out = (p.stdout or "") + (p.stderr or "") + "\n[exit %d]" % p.returncode
    except subprocess.TimeoutExpired:
        out = "[timeout]"
    return out[-OBS_CAP:]


def run_write(rel, body):
    if not rel or os.path.isabs(rel) or ".." in rel.split("/"):
        return "rejected path: " + rel
    dest = os.path.join(CWD, rel)
    try:
        d = os.path.dirname(dest)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(dest, "w", encoding="utf-8") as f:
            f.write(body + "\n")
        return "wrote " + rel + " (%d chars)" % len(body)
    except OSError as e:
        return "write failed: %s" % e


def main():
    history = []
    steps = 0
    while steps < MAX_STEPS:
        left = cellapi.calls_left()
        if left <= 0:
            break
        try:
            reply = cellapi.brain(SYSTEM, build_prompt(history, left))
        except Exception:
            break
        steps += 1
        reply = str(reply or "")
        act = parse(reply)
        if act is None:
            history.append((reply[:300], "no valid action found; reply with exactly one action"))
            continue
        kind, arg, body = act
        if kind == "done":
            break
        if kind == "sh":
            history.append((SH + "\n" + body[:600], run_sh(body)))
        else:
            history.append((WR + " " + arg + "\n" + body[:600], run_write(arg, body)))


if __name__ == "__main__":
    main()
