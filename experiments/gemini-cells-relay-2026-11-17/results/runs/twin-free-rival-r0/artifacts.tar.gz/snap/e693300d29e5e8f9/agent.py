"""Harness v4 (cell B): spec preloaded, bounded loop, robust parser.
Run with the task folder as working directory."""
import os
import subprocess

import cellapi

CWD = os.getcwd()
OBS_CAP = 1500
SPEC_CAP = 5000
PROMPT_CAP = 13000
MAX_STEPS = 12
SPEC_NAMES = ("TASK.md", "FORMAT.md", "SPEC.md")

SYSTEM = """You are a cell: an agent working inside a task folder through a text protocol.
Each reply contains exactly ONE action, in one of these forms, and nothing else:

@sh
<shell commands, run in the task folder>
EOB

@write <relative/path>
<file content>
EOB

@done

Rules:
- Read the spec files shown in the prompt completely before coding. Every rule is instance-specific.
- Write the solver and run it in the same action when you can. Save calls.
- If an example/ folder with expected output exists, run the solver on it first and compare.
  Fix the parser before running on data/.
- When a parser rejects rows, print the count and a sample per reason, and check each reason
  against the spec. Never drop rows silently.
- Always leave a valid answer file. Write it before @done and verify it with a JSON load.
- Keep outputs short (head -c 1500). Never cat a whole data file.
- Do not name files after Python stdlib modules (json.py, csv.py, re.py) in the task folder.
- Keep reasoning short. Do not write a reply that is cut off.
""".replace("EOB", "@end")


def read(path, n):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read(n)
    except OSError as e:
        return "(cannot read %s: %s)" % (path, e)


def spec_text():
    parts = []
    for name in SPEC_NAMES:
        p = os.path.join(CWD, name)
        if os.path.isfile(p):
            parts.append("=== %s ===\n%s" % (name, read(p, SPEC_CAP)))
    return "\n".join(parts)


def listing():
    try:
        names = sorted(os.listdir(CWD))
    except OSError:
        names = []
    return ("folder: " + " ".join(names))[:800]


def run_sh(body):
    try:
        p = subprocess.run(body, shell=True, capture_output=True, text=True,
                           timeout=20, cwd=CWD)
        return (p.stdout + p.stderr) or "(no output)"
    except subprocess.TimeoutExpired:
        return "(timed out after 20 s)"


def run_write(path, body):
    full = os.path.normpath(os.path.join(CWD, path))
    if not (full == CWD or full.startswith(CWD + os.sep)):
        return "refused: path outside task folder"
    os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(body if body.endswith("\n") else body + "\n")
    return "wrote %s (%d chars)" % (path, len(body))


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if not s.startswith("@"):
            continue
        if s == "@done":
            return ("done", "", "")
        if s == "@sh" or s.startswith("@write"):
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            text = "\n".join(body)
            if s == "@sh":
                return ("sh", "", text)
            return ("write", s[len("@write"):].strip(), text)
    return None


def build_prompt(history, left):
    head = spec_text() + "\n=== " + listing() + "\n"
    if left <= 1:
        tail_note = "This is your LAST model call: make sure the answer file is written, then reply @done."
    else:
        tail_note = "Model calls left: %d." % left
    budget = PROMPT_CAP - len(head) - len(tail_note) - 50
    entries = []
    used = 0
    for item in reversed(history):
        e = "--- your action ---\n%s\n--- result ---\n%s\n" % item
        if used + len(e) > budget:
            break
        entries.append(e)
        used += len(e)
    entries.reverse()
    return head + "".join(entries) + "\n" + tail_note


def main():
    history = []
    steps = 0
    while steps < MAX_STEPS:
        try:
            left = cellapi.calls_left()
        except Exception:
            break
        if left <= 0:
            break
        try:
            reply = cellapi.brain(SYSTEM, build_prompt(history, left))
        except Exception:
            break
        steps += 1
        reply = str(reply or "")
        act = parse(reply)
        if act is None:
            history.append((reply[:300], "no valid action found; reply with exactly one action"))
            continue
        kind, arg, body = act
        if kind == "done":
            break
        if kind == "sh":
            out = run_sh(body)
            history.append(("@sh\n" + body[:600], out[:OBS_CAP]))
        else:
            out = run_write(arg, body)
            history.append(("@write " + arg + "\n" + body[:600], out[:OBS_CAP]))


if __name__ == "__main__":
    main()
