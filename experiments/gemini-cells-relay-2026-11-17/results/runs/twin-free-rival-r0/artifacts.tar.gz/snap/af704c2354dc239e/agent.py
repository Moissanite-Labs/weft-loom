"""Cell harness v2: pre-gathers task context, runs one action per reply."""
import os
import subprocess
import sys

import cellapi

OBS_CAP = 3000
HIST_CAP = 7000
CTX_CAP = 7500

SYSTEM = "\n".join([
    "You are a cell working in the current folder. TASK.md describes the task.",
    "You have very few model calls. Be efficient. In your FIRST reply, read the spec files",
    "and, if you can, write AND run the solver in the same action.",
    "Reply with exactly ONE action, in one of these forms, and nothing else:",
    "@sh",
    "<shell commands, run in the task folder>",
    "@end",
    "",
    "@write <relative/path>",
    "<file content>",
    "@end",
    "",
    "@done",
    "Rules: read FORMAT.md and TASK.md completely before coding; every rule is instance-specific.",
    "If an example/ folder with expected output exists, run your solver on it and compare",
    "before running on data/. Write the required output file before @done.",
    "Do not name files after python stdlib modules (json.py, csv.py, re.py) in the task folder.",
    "Keep commands short; observations are capped.",
])


def gather():
    cwd = os.getcwd()
    files = []
    for root, dirs, fs in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for f in sorted(fs):
            files.append(os.path.relpath(os.path.join(root, f), cwd))
    files.sort(key=lambda p: (not p.endswith(".md"), p))
    parts = ["FILES:\n" + "\n".join(files[:150])]
    used = len(parts[0])
    for f in files:
        limit = 4000 if f.endswith((".md", ".txt")) else 400
        try:
            with open(os.path.join(cwd, f), "r", errors="replace") as fh:
                text = fh.read(limit)
        except OSError:
            continue
        chunk = "\n\n=== " + f + " ===\n" + text
        if used + len(chunk) > CTX_CAP:
            break
        parts.append(chunk)
        used += len(chunk)
    return "".join(parts)


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s == "@done":
            return ("done", None, "")
        if s == "@sh" or s.startswith("@write "):
            path = s[len("@write "):].strip() if s.startswith("@write ") else None
            kind = "write" if path is not None else "sh"
            body = []
            for l in lines[i + 1:]:
                if l.strip() == "@end":
                    break
                body.append(l)
            return (kind, path, "\n".join(body) + "\n")
    return None


def run_sh(body):
    try:
        p = subprocess.run(["bash", "-c", body], cwd=os.getcwd(), capture_output=True,
                           text=True, timeout=18)
        obs = (p.stdout or "") + (p.stderr or "") + "\n[exit " + str(p.returncode) + "]"
    except subprocess.TimeoutExpired:
        obs = "[command timed out after 18s]"
    if len(obs) > OBS_CAP:
        obs = obs[:OBS_CAP // 2] + "\n[...cut...]\n" + obs[-OBS_CAP // 2:]
    return obs


def write_file(path, body):
    base = os.getcwd()
    full = os.path.normpath(os.path.join(base, path))
    if not full.startswith(base + os.sep):
        return "Refused: path must stay inside the task folder."
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, "w") as fh:
        fh.write(body)
    return "Wrote " + path + " (" + str(len(body)) + " chars)."


def main():
    context = gather()
    history = []
    while True:
        hist = "".join(history)
        if len(hist) > HIST_CAP:
            hist = "[earlier steps cut]\n" + hist[-HIST_CAP:]
        try:
            left = cellapi.calls_left()
        except Exception:
            left = "unknown"
        prompt = ("TASK CONTEXT:\n" + context + "\n\nPREVIOUS STEPS:\n" + hist +
                  "\n\nModel calls left: " + str(left) + ". Your next action:")
        try:
            reply = cellapi.brain(SYSTEM, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Reply with exactly one @sh ... @end, @write ... @end, or @done."
        elif action[0] == "done":
            break
        elif action[0] == "sh":
            obs = run_sh(action[2])
        else:
            try:
                obs = write_file(action[1], action[2])
            except Exception as exc:
                obs = "Write error: " + type(exc).__name__ + ": " + str(exc)
        history.append("\n--- your action ---\n" + reply.strip()[:1500] +
                       "\n--- result ---\n" + obs + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
