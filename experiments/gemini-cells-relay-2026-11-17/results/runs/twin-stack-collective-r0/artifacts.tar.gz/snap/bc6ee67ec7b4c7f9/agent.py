"""Harness: loop, prompt and tools. Run with the task folder as the working directory."""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000
MAX_STEPS = 40
PROMPT_CAP = 15000
DOC_CAP = 9000
REPLY_CAP = 1500


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def folder_context(cwd):
    """Folder listing plus top-level .md docs, so the model needs no calls to look them up."""
    files = []
    for root, dirs, names in os.walk(cwd):
        dirs.sort()
        for n in sorted(names):
            rel = os.path.relpath(os.path.join(root, n), cwd)
            if rel != "TASK.md":
                files.append(rel)
    out = "Files in your folder:\n" + "\n".join(files[:80]) + "\n"
    docs = [f for f in files if os.sep not in f and f.lower().endswith(".md")]
    budget = DOC_CAP
    for d in docs:
        if budget <= 0:
            break
        try:
            with open(os.path.join(cwd, d)) as fh:
                text = fh.read()[:min(budget, 8000)]
        except OSError:
            continue
        out += f"\n== {d}\n{text}\n"
        budget -= len(text)
    return out


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    fixed = "TASK.md:\n" + task + "\n\n" + folder_context(cwd) + "\n"
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        footer = f"\nModel calls left: {left}. Your next action:"
        room = PROMPT_CAP - len(fixed) - len(footer)
        hist = ""
        for h in reversed(history):
            if len(hist) + len(h) > room:
                break
            hist = h + hist
        prompt = fixed + hist + footer
        try:
            reply = cellapi.brain(system, prompt) or ""
        except Exception as e:
            history.append(f"\n[model error: {e}]\n")
            continue
        short = reply.strip()[:REPLY_CAP]
        action = parse(reply)
        if action is None:
            history.append(f"\n[your reply]\n{short}\n[result]\nNo action found. Reply with one action in the required form.\n")
            continue
        tool, arg, body = action
        if tool == "done":
            break
        if tool not in tools:
            res = f"Unknown action '{tool}'."
        else:
            try:
                res = str(tools[tool].run(arg, body, {"cwd": cwd}))
            except Exception as e:
                res = f"Tool error: {e}"
        if len(res) > OBS_CAP:
            res = res[:OBS_CAP] + f"\n...[cut, {len(res)} chars total]"
        history.append(f"\n[your reply]\n{short}\n[result]\n{res}\n")


if __name__ == "__main__":
    main()
