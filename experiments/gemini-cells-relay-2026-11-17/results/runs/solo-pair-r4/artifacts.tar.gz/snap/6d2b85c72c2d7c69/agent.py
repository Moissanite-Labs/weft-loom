"""Harness with a preamble: the folder listing, the task's .md spec files and sample data are shown in the first prompt, so the model does not need calls to look around."""
import importlib.util
import os
import subprocess
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000          # characters of tool output shown back to the model
MAX_STEPS = 40          # the referee's call cap usually ends the episode first
PROMPT_BUDGET = 14000   # the referee allows 16000 characters per prompt
PREAMBLE_BUDGET = 6000  # characters of task-folder preamble


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def read_text(path, limit):
    try:
        with open(path, errors="replace") as f:
            data = f.read(limit + 1)
    except OSError:
        return "(unreadable)"
    if len(data) > limit:
        data = data[:limit] + "\n[cut]"
    return data


def preamble(cwd):
    """Folder listing, root .md specs, and small samples of data files. Costs no model calls."""
    files = []
    for root, dirs, names in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for n in sorted(names):
            rel = os.path.relpath(os.path.join(root, n), cwd)
            if rel != "TASK.md":
                files.append(rel)
    parts = ["Files in task folder (%d):\n%s" % (len(files), "\n".join(files[:120]))]
    for rel in files:
        if os.path.dirname(rel) == "" and rel.endswith(".md"):
            parts.append("=== %s ===\n%s" % (rel, read_text(os.path.join(cwd, rel), 5000)))
    for rel in files:
        if rel.endswith("expected.json"):
            parts.append("=== %s ===\n%s" % (rel, read_text(os.path.join(cwd, rel), 600)))
    samples = [r for r in files if "/data/" in "/" + r and os.path.dirname(r) != ""]
    for rel in samples[:3]:
        parts.append("=== sample %s (head) ===\n%s" % (rel, read_text(os.path.join(cwd, rel), 250)))
    text = "\n\n".join(parts)
    if len(text) > PREAMBLE_BUDGET:
        text = text[:PREAMBLE_BUDGET] + "\n[preamble cut]"
    return text


def build_prompt(task, pre, history, left):
    header = "TASK.md:\n" + task + "\n\n" + pre + "\n\n"
    footer = "\nModel calls left: %d. Your next action:" % left
    room = PROMPT_BUDGET - len(header) - len(footer)
    kept = []
    total = 0
    for entry in reversed(history):
        if total + len(entry) > room:
            break
        kept.append(entry)
        total += len(entry)
    return header + "".join(reversed(kept)) + footer


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    pre = preamble(cwd)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, pre, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Reply with an @sh ... @end block, an @write block, or @done."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = "Unknown tool %s." % action[0]
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = "Tool error: %s: %s" % (type(exc).__name__, exc)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append("\n--- step %d ---\n%s\n--- result ---\n%s\n" % (step + 1, reply.strip(), obs))


if __name__ == "__main__":
    sys.exit(main())
