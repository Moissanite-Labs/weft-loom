NAME = "sh"
HELP = "@sh ... @end : run shell commands in the task folder (python3 available, 20 s limit)."


def run(arg, body, ctx):
    import subprocess
    try:
        p = subprocess.run(
            ["bash", "-lc", body], cwd=ctx["cwd"], capture_output=True, text=True, timeout=20
        )
        out = (p.stdout or "") + (p.stderr or "")
        return out if out.strip() else f"(exit {p.returncode}, no output)"
    except subprocess.TimeoutExpired:
        return "Timed out after 20 s."
