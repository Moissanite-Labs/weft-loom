"""Builder-improved harness. Same interface: cellapi.brain / cellapi.calls_left.

Changes from the seed: larger observation cap with head+tail kept, prompt size kept
under the referee's 16000-character limit by dropping the oldest steps, and a
call-aware nudge so the last call is spent on a finished deliverable.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 5000       # characters of tool output shown back to the model
PROMPT_CAP = 14500   # stay under the 16000-character prompt limit
TASK_CAP = 6000
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def cut_middle(text, cap):
    if len(text) <= cap:
        return text
    half = cap // 2
    return text[:half] + "\n[... output cut ...]\n" + text[-half:]


def build_prompt(task, history, left):
    head = "TASK.md:\n" + cut_middle(task, TASK_CAP) + "\n\n"
    if left <= 1:
        note = "This is your LAST model call. Make sure the deliverable is written and checked now.\n"
    else:
        note = ""
    tail = f"\nModel calls left: {left}. {note}Your next action:"
    room = PROMPT_CAP - len(head) - len(tail)
    hist = "".join(history)
    if len(hist) > room:
        hist = "\n[older steps dropped]\n" + hist[-max(room - 30, 0):]
    return head + hist + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Reply with exactly one @tool ... @end block."
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]!r}. Known tools: {', '.join(sorted(tools))}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = cut_middle(str(obs), OBS_CAP)
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
