"""Harness v3. Pre-reads the task folder into the first prompt so the model spends no calls on reading.
Runs the actions in a reply in order, stops at @done, keeps prompts under the 16000-char limit."""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3500
HIST_CAP = 6000
TASK_CAP = 2500
PREREAD_CAP = 8000
MAX_STEPS = 40
DOC_NAMES = ("FORMAT.md", "SPEC.md", "README.md", "README", "RULES.md")


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def clip(s, n):
    if len(s) <= n:
        return s
    head = (n * 2) // 3
    tail = n - head
    return s[:head] + f"\n...[{len(s) - n} chars cut]...\n" + s[-tail:]


def read_text(path, n):
    try:
        with open(path, "r", errors="replace") as f:
            return clip(f.read(), n)
    except Exception as e:
        return f"(could not read: {e!r})"


def preread(cwd):
    """Build a read-only digest of the task folder: file listing, docs, and example expected output."""
    listing = []
    docs = []
    expected = []
    for root, dirs, files in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith(".") and d != "target")
        for f in sorted(files):
            rel = os.path.relpath(os.path.join(root, f), cwd)
            listing.append(rel)
            if f in DOC_NAMES or (f.endswith(".md") and f != "TASK.md" and f != "prompt.md"):
                docs.append(rel)
            if "expected" in f and f.endswith(".json"):
                expected.append(rel)
    parts = ["== FILE LISTING (first 120) ==", "\n".join(listing[:120])]
    if len(listing) > 120:
        parts.append(f"...({len(listing) - 120} more files)")
    for rel in docs[:4]:
        parts.append(f"== {rel} ==\n" + read_text(os.path.join(cwd, rel), 3500))
    for rel in expected[:3]:
        parts.append(f"== {rel} ==\n" + read_text(os.path.join(cwd, rel), 800))
    return clip("\n".join(parts), PREREAD_CAP)


def parse_actions(reply):
    actions = []
    lines = reply.splitlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s == "@done":
            actions.append(("done", "", ""))
            break
        if s.startswith("@") and not s.startswith("@end"):
            head = s[1:].split(None, 1)
            if head:
                body = []
                i += 1
                while i < len(lines) and lines[i].strip() != "@end":
                    body.append(lines[i])
                    i += 1
                actions.append((head[0], head[1] if len(head) > 1 else "", "\n".join(body)))
        i += 1
    return actions


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = clip(f.read(), TASK_CAP)
    digest = preread(cwd)

    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        hist = "".join(history)
        if len(hist) > HIST_CAP:
            hist = "...(older steps dropped)...\n" + hist[-HIST_CAP:]
        prompt = (
            "TASK.md:\n" + task + "\n\n"
            + "PRE-READ DIGEST (already read for you, do not re-read these in full):\n" + digest + "\n\n"
            + hist
            + f"\nModel calls left: {left}. Your next action:"
        )
        if step > 0:
            # later steps: keep the digest out to stay under the prompt limit
            prompt = (
                "TASK.md:\n" + task + "\n\n"
                + "DIGEST (first 1500 chars):\n" + clip(digest, 1500) + "\n\n"
                + hist
                + f"\nModel calls left: {left}. Your next action:"
            )
        try:
            reply = cellapi.brain(system, prompt) or ""
        except cellapi.BudgetExhausted:
            break
        except Exception as e:
            history.append(f"\n[harness error: {e!r}]\n")
            continue
        history.append(f"\n--- step {step + 1}: your reply ---\n{clip(reply.strip(), 2500)}\n")

        actions = parse_actions(reply)
        if not actions:
            history.append("--- result ---\n(no action found. Reply with @sh, @write or @done.)\n")
            continue
        done = False
        for name, arg, body in actions:
            if name == "done":
                done = True
                break
            tool = tools.get(name)
            if tool is None:
                out = f"unknown action @{name}"
            else:
                try:
                    out = str(tool.run(arg, body, {"cwd": cwd}))
                except Exception as e:
                    out = f"tool error: {e!r}"
            history.append(f"--- result of @{name} ---\n{clip(out, OBS_CAP)}\n")
        if done:
            break


if __name__ == "__main__":
    main()
