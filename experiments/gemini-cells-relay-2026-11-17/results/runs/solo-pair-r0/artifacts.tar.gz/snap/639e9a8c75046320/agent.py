"""Harness: loads the task spec into the first prompt so the model does not spend a call reading it."""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000        # characters of tool output shown back to the model
SPEC_CAP = 7000       # characters per spec file included up front
PROMPT_CAP = 15000    # keep every prompt under the referee's 16000 character limit
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s == "@done":
            return "done", "", ""
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def cap(text, n):
    if len(text) <= n:
        return text
    return text[:n // 2] + "\n...[cut]...\n" + text[-n // 2:]


def workspace_summary(cwd):
    """Task text, every top-level .md spec, and a file listing, all shown up front."""
    parts = []
    with open(os.path.join(cwd, "TASK.md")) as f:
        parts.append("TASK.md:\n" + cap(f.read(), SPEC_CAP))
    for name in sorted(os.listdir(cwd)):
        if name.endswith(".md") and name != "TASK.md":
            with open(os.path.join(cwd, name)) as f:
                parts.append(f"{name}:\n" + cap(f.read(), SPEC_CAP))
    listing = []
    for root, dirs, files in os.walk(cwd):
        for fn in files:
            rel = os.path.relpath(os.path.join(root, fn), cwd)
            listing.append(rel)
        if len(listing) > 120:
            break
    parts.append("Files in your folder:\n" + "\n".join(sorted(listing)[:120]))
    return "\n\n".join(parts)


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    header = workspace_summary(cwd)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        tail = f"\nModel calls left: {left}. Your next action:"
        # drop the oldest history entries until the prompt fits
        while True:
            prompt = header + "\n\n" + "".join(history) + tail
            if len(prompt) <= PROMPT_CAP or not history:
                break
            history.pop(0)
        if len(prompt) > PROMPT_CAP:
            prompt = cap(prompt, PROMPT_CAP)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply or "")
        if action is None:
            history.append("\nNo action found. Reply with exactly one action in the required form.\n")
            continue
        name, arg, body = action
        if name == "done":
            break
        tool = tools.get(name)
        if tool is None:
            result = f"Unknown tool @{name}. Available: {', '.join(sorted(tools))}"
        else:
            try:
                result = tool.run(arg, body, {"cwd": cwd})
            except Exception as e:  # keep the loop alive on tool errors
                result = f"tool error: {e!r}"
        result = cap(str(result), OBS_CAP)
        history.append(f"\nAction: @{name} {arg}\nResult:\n{result}\n")


if __name__ == "__main__":
    main()
