"""Cell harness, builder version 2.

Run with the task folder as the working directory. The model is reached through cellapi.
The harness reads the task files before the first model call, so the model
does not spend its few calls on exploration.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2000
TASK_CAP = 3000
CONTEXT_CAP = 7000
PROMPT_CAP = 15000
MAX_STEPS = 40
SKIP_DIRS = {"target", ".git", "__pycache__"}


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("@") and not s.startswith("@end"):
            parts = s[1:].split(None, 1)
            if not parts:
                continue
            name = parts[0]
            arg = parts[1].strip() if len(parts) > 1 else ""
            if name == "done":
                return "done", "", ""
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return name, arg, "\n".join(body)
    return None


def read_text(path, limit):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read(limit)
    except OSError as exc:
        return f"(unreadable: {exc})"


def rank(path):
    if path.endswith(".md"):
        return 0
    if path.endswith(".py"):
        return 1
    if path.endswith(".json"):
        return 2
    return 3


LIMITS = {0: 3000, 1: 1500, 2: 600, 3: 400}


def preload(cwd):
    files = []
    for root, dirs, names in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        if root[len(cwd):].count(os.sep) > 3:
            dirs[:] = []
        for n in sorted(names):
            if n.startswith("."):
                continue
            files.append(os.path.relpath(os.path.join(root, n), cwd))
    files = [f for f in files if f != "TASK.md"]
    listing = "FILES: " + ", ".join(files)[:1500] + "\n"
    out = [listing]
    used = len(listing)
    for p in sorted(files, key=lambda p: (rank(p), p)):
        chunk = f"\n--- {p} ---\n" + read_text(os.path.join(cwd, p), LIMITS[rank(p)])
        if used + len(chunk) > CONTEXT_CAP:
            continue
        out.append(chunk)
        used += len(chunk)
    return "".join(out)


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()[:TASK_CAP]
    try:
        context = preload(cwd)
    except Exception as exc:
        context = f"(preload failed: {exc})"
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        head = ("TASK.md:\n" + task + "\n\nFILES ALREADY READ FOR YOU (do not re-read these):\n"
                + context + "\n\n")
        footer = f"\nModel calls left: {left}. Your next action:"
        room = max(0, PROMPT_CAP - len(head) - len(footer))
        past = "".join(history)
        if len(past) > room:
            past = "[earlier steps trimmed]\n" + past[-max(0, room - 30):]
        prompt = head + past + footer
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = str(obs)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
