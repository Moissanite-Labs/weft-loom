"""Harness for a cell. Pre-reads the task folder so the model starts with rules and data samples."""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
PROMPT_BUDGET = 15000
OBS_CAP = 3000
REPLY_CAP = 1500
PRE_CAP = 7000
MAX_STEPS = 40
SKIP_DIRS = {".git", "__pycache__"}
END = "@" + "end"

SYSTEM = """You are a cell: a model inside a small harness. You work in one folder. TASK.md and a pre-read
of the folder's files are in the prompt; the harness read them, so no model call was spent on that.

You have very few model calls (about 3). Each reply is exactly one action, nothing else.
A shell action starts with the line @sh, then shell commands, and is closed by a line that holds only the end marker (the at-sign followed by the word end).
A file write starts with the line @write and a path, then the file content, closed by the same end marker line.
To finish, reply with the single line @done.

Strategy:
- Use the pre-read: it holds the rules, the output format and data samples. Do not spend a call just to look around.
- Make your first action complete. One shell action can write a script with a heredoc and run it.
- If there is an example folder with an expected answer, run your solver on it and compare before the real data.
- The output file is what gets scored. Write it exactly in the requested format and check that it parses.
- Bugfix tasks: read the spec and failing tests, fix the code, run the tests again.
- On your last call, make sure the output is written, then reply @done.
"""


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith(END):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == END:
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def cap_obs(text):
    if len(text) <= OBS_CAP:
        return text
    half = OBS_CAP // 2
    return text[:half] + "\n...[middle cut]...\n" + text[-half:]


def scan(cwd):
    files = []
    for root, dirs, names in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        for n in sorted(names):
            files.append(os.path.relpath(os.path.join(root, n), cwd))
    return files


def prio(rel):
    base = os.path.basename(rel).upper()
    if any(k in base for k in ("FORMAT", "SPEC", "README", "RULE", "NOTES")):
        return 1
    if rel.endswith(".md"):
        return 2
    return 3


def preread(cwd):
    files = scan(cwd)
    listing = "\n".join(files[:120]) or "(empty)"
    out = ["Files in your folder:", listing]
    used = len(listing)
    order = sorted((f for f in files if f != "TASK.md"), key=lambda r: (prio(r), r))
    for rel in order:
        if used > PRE_CAP:
            break
        p = os.path.join(cwd, rel)
        try:
            if os.path.getsize(p) > 200000:
                continue
            with open(p, "rb") as f:
                raw = f.read()
        except OSError:
            continue
        if b"\0" in raw:
            continue
        text = raw.decode("utf-8", "replace")
        limit = 2500 if prio(rel) <= 2 else 400
        if len(text) > limit:
            text = text[:limit] + f"\n...[cut, {len(text)} chars total]"
        block = f"--- {rel} ---\n{text}"
        out.append(block)
        used += len(block)
    return "\n".join(out)


def build_prompt(task, pre, history, left):
    head = "TASK.md:\n" + task + "\n\nPre-read of your folder (no model call used):\n" + pre + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    entries = list(history)
    while True:
        body = head + "".join(entries) + tail
        if len(body) <= PROMPT_BUDGET or not entries:
            break
        entries.pop(0)
    if len(body) > PROMPT_BUDGET:
        body = body[:PROMPT_BUDGET - len(tail)] + tail
    return body


def main():
    cwd = os.getcwd()
    tools = load_tools()
    system = SYSTEM + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    pre = preread(cwd)
    history = []
    for _ in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, pre, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        reply = reply or ""
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool form with the end marker, or @done."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        history.append(f"\nYou replied:\n{reply[:REPLY_CAP]}\nResult:\n{cap_obs(str(obs))}\n")


if __name__ == "__main__":
    main()
