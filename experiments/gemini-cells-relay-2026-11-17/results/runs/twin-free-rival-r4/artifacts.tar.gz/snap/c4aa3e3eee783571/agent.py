"""Harness v3. Spec files are shown up front in the first prompt, so the model's calls go to writing and testing code."""
import importlib.util
import re
import os
import subprocess
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000
SPEC_CAP = 10000
PROMPT_CAP = 15000
MAX_STEPS = 40
END = "@" + "end"

SYSTEM = """You are a cell: a model inside a small harness. You work in one folder. Your task is in TASK.md.

Reply with exactly one action per reply, in one of these forms, and nothing else:

@sh
<shell commands>
{E}

@write <path>
<file content>
{E}

@done

Working rules:
- The spec files (*.md) and the example file list are already shown below in full. Do not spend a call re-reading them unless a part was marked [cut].
- Your next call must be a @write of one complete solver script that implements EVERY rule in the spec: comment lines, continuation lines, separators and split limits, timestamp parsing and time zones, level names, rounding, edge cases, and the exact output shape. Write the required output file from the solver.
- Then run the solver on example/ and compare with example/expected.json. Fix only what differs. Then run it on data/ and make sure the required output file exists with the required shape.
- Never repeat a command whose output you have already seen. Do not stop with @done before the required output file exists.
""".replace("{E}", END)


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


CLOSERS = {END, "</invoke>", "</invoke_block>", "</invoke>"}
HEAD_RE = re.compile(r"^\s*(?:<invoke[:\s]*|@)(sh|write|done)\b\s*(.*)$")


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None.
    Accepts @sh / @write / @done and the <invoke:sh form; a block ends at @end or a closing tag."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        m = HEAD_RE.match(line)
        if not m:
            continue
        body = []
        for nxt in lines[i + 1:]:
            if nxt.strip() in CLOSERS:
                break
            body.append(nxt)
        return m.group(1), m.group(2).strip(), "\n".join(body)
    return None


def cap(text, limit):
    if len(text) > limit:
        return text[:limit] + "\n[cut]"
    return text


def sh(cwd, cmd, limit):
    try:
        out = subprocess.run(["bash", "-c", cmd], cwd=cwd, capture_output=True, text=True, timeout=15)
        text = out.stdout + out.stderr
    except Exception as exc:
        text = f"error: {exc}"
    return cap(text, limit)


def gather(cwd):
    """Read the task and every spec file up front, so the first call can already be code."""
    parts = []
    names = sorted(n for n in os.listdir(cwd) if n.endswith((".md", ".txt")) and os.path.isfile(os.path.join(cwd, n)))
    if "TASK.md" in names:
        names.remove("TASK.md")
        names.insert(0, "TASK.md")
    budget = SPEC_CAP
    for name in names:
        if budget <= 200:
            break
        try:
            with open(os.path.join(cwd, name), encoding="utf-8", errors="replace") as f:
                body = f.read()
        except Exception as exc:
            body = f"(could not read: {exc})"
        share = max(1200, budget // max(1, len(names)))
        piece = cap(body, min(share, budget))
        budget -= len(piece)
        parts.append(f"===== FILE {name} =====\n{piece}")
    ex = os.path.join(cwd, "example", "expected.json")
    if os.path.isfile(ex):
        with open(ex, encoding="utf-8", errors="replace") as f:
            parts.append("===== FILE example/expected.json =====\n" + cap(f.read(), 1500))
    parts.append("===== FILE LIST =====\n" + sh(cwd, "find . -type f -not -path './.*' | head -80", 1500))
    return "\n\n".join(parts)


def build_prompt(initial, history, left):
    head = initial + f"\n\nModel calls left: {left}. Your next action:"
    room = PROMPT_CAP - len(head) - 200
    chunks = []
    skipped = 0
    for entry in reversed(history):
        if len(entry) > room:
            skipped += 1
            continue
        chunks.append(entry)
        room -= len(entry)
    chunks.reverse()
    note = f"\n[{skipped} earlier steps not shown]" if skipped else ""
    return head + note + "".join(chunks)


def main():
    cwd = os.getcwd()
    tools = load_tools()
    initial = gather(cwd)
    history = []
    step = 0
    while step < MAX_STEPS:
        try:
            left = int(cellapi.calls_left())
        except Exception:
            left = 0
        if left <= 0:
            break
        prompt = build_prompt(initial, history, left)
        try:
            reply = cellapi.brain(SYSTEM, prompt) or ""
        except Exception:
            break
        step += 1
        action = parse(reply)
        if action is None:
            history.append(f"\n--- step {step} ---\n{reply.strip()[:400]}\n--- result ---\n"
                           "No action found. Reply with one @sh, @write or @done block.\n")
            continue
        if action[0] == "done":
            break
        if action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = cap(str(obs), OBS_CAP)
        history.append(f"\n--- step {step} ---\n{reply.strip()}\n--- result ---\n{obs}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
