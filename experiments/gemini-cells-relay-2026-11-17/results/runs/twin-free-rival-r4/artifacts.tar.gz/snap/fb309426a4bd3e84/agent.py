"""Harness v3: same action format and tools (sh, write, done) as the seed, tuned for a
3-call budget: bigger observations, a bounded prompt, and newest-first history."""
import os
import subprocess

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
END = "@" + "end"      # block terminator, built here so no bare terminator line appears in source
PROMPT_LIMIT = 15000   # system + prompt must stay under the referee's 16000 characters
TASK_CAP = 6000        # characters of TASK.md shown
OBS_MAX = 3000         # characters of each tool result shown
SH_TIMEOUT = 18        # the referee allows 20 s per task command

HELP = "\n".join([
    "@sh",
    "<shell commands, run in the task folder, about 18 s limit, output shown back to you>",
    END,
    "",
    "@write <path>",
    "<full file content, relative to the task folder>",
    END,
    "",
    "@done",
    "<no body: ends the episode once the required output is in place>",
])


def cap(text, n):
    if len(text) <= n:
        return text
    head = int(n * 0.7)
    tail = n - head - 40
    return text[:head] + "\n...[middle cut]...\n" + text[-tail:]


def parse(reply):
    """Return (name, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if not s.startswith("@") or s.startswith(END):
            continue
        parts = s[1:].split(None, 1)
        if not parts:
            continue
        name = parts[0]
        arg = parts[1] if len(parts) > 1 else ""
        if name == "done":
            return ("done", "", "")
        if name not in ("sh", "write"):
            continue
        body = []
        for nxt in lines[i + 1:]:
            if nxt.strip() == END:
                break
            body.append(nxt)
        return (name, arg.strip(), "\n".join(body))
    return None


def run_sh(body, cwd):
    try:
        p = subprocess.run(["bash", "-c", body], cwd=cwd, capture_output=True,
                           text=True, timeout=SH_TIMEOUT)
        out = (p.stdout or "") + (p.stderr or "")
        return out + f"\n[exit {p.returncode}]"
    except subprocess.TimeoutExpired as e:
        out = (e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or ""))
        return out + "\n[timed out after %ds]" % SH_TIMEOUT
    except Exception as e:
        return f"[shell error: {e}]"


def run_write(path, body, cwd):
    full = path if os.path.isabs(path) else os.path.join(cwd, path)
    d = os.path.dirname(full)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(full, "w") as f:
        f.write(body if body.endswith("\n") else body + "\n")
    return f"wrote {path} ({len(body)} chars)"


def build_prompt(task, hist, left, system_len):
    head = "TASK.md:\n" + cap(task, TASK_CAP) + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    room = PROMPT_LIMIT - system_len - len(head) - len(tail) - 100
    out, used = [], 0
    for act, obs in reversed(hist):
        block = f"=== your action ===\n{act}\n=== result ===\n{cap(obs, OBS_MAX)}\n"
        if used + len(block) > room:
            if not out:
                block = cap(block, max(room, 200))
            else:
                break
        out.append(block)
        used += len(block)
    out.reverse()
    omitted = "[older steps omitted]\n" if len(out) < len(hist) else ""
    return head + omitted + "".join(out) + tail


def main():
    cwd = os.getcwd()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\n\nActions:\n" + HELP
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    hist = []
    errors = 0
    for _ in range(40):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, hist, left, len(system))
        try:
            reply = cellapi.brain(system, prompt)
            errors = 0
        except cellapi.BudgetExhausted:
            break
        except Exception as e:
            errors += 1
            hist.append(("(model call failed)", f"error: {e}"))
            if errors >= 2:
                break
            continue

        action = parse(reply)
        if action is None:
            hist.append((cap(reply, 300), "Could not read an action. Reply with exactly one "
                         "@sh block, @write block, or @done."))
            continue
        name, arg, body = action
        if name == "done":
            break
        if name == "sh":
            obs = run_sh(body, cwd)
            act = "@sh\n" + cap(body, 800) + "\n" + END
        else:
            try:
                obs = run_write(arg, body, cwd)
            except Exception as e:
                obs = f"write failed: {e}"
            act = f"@write {arg}\n" + cap(body, 400) + "\n" + END
        hist.append((act, obs))


if __name__ == "__main__":
    main()
