"""Harness for the cell. Loop, prompt and tools in one file.

Run with the task folder as the working directory. The model is reached only
through cellapi.brain(system, prompt) and cellapi.calls_left().
"""
import os
import subprocess

import cellapi

OBS_CAP = 3500        # characters of tool output shown back to the model
REPLY_CAP = 3000      # characters of the model's own reply kept in history
PROMPT_CAP = 12000    # system prompt (~2000 chars) plus this must stay under 16000
MAX_STEPS = 40
END = "@" + "end"     # the closing marker; kept out of this source file on purpose

_SYSTEM_RAW = """You are a cell: a model inside a small harness. You work in one folder.
Your task is in TASK.md, shown in the prompt. Some tasks come with a FORMAT.md or
example files that state the exact rules: read them completely.

Reply with exactly ONE action, in this form, and nothing else:

@sh
<shell commands>
{END}

@write <path>
<file content>
{END}

@done

Tools:
- @sh ... {END} : run shell commands in the task folder (python3 is available, 20 s limit;
  output is cut to about 3500 characters, so print only what you need).
- @write <path> ... {END} : create or overwrite a file (relative paths are in the task folder).
  The body ends at the first line that is exactly {END}, so file content must never contain
  such a line.
- @done : finish the episode.

Rules for working well:
- Your model calls are few (about 3). Make each action count.
- Action 1: read everything at once in ONE @sh: the full TASK.md, every instruction file
  (FORMAT.md etc.), the file listing, the first lines of each data file, and any example
  with its expected output.
- Then write a complete, self-checking script in ONE @write that implements every rule in
  the instructions in the order given, handles messy input robustly, and prints diagnostics.
  Check the script against the example's expected output, and fix it if they differ.
- Then run it in ONE @sh: run it on the example (compare to the expected answer) and on the
  real data, and write the required output file.
- Always make sure a required output file exists and is valid before @done, even if only
  partly right: scores are usually per item, so partial output still counts.
- Never invent rules that the instructions do not state."""

SYSTEM = _SYSTEM_RAW.replace("{END}", END)


def clip(s, n):
    if len(s) <= n:
        return s
    h = int(n * 0.7)
    t = n - h
    return s[:h] + f"\n...[{len(s) - n} characters cut]...\n" + s[-t:]


def parse(reply):
    """Return (kind, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s == "@done":
            return "done", "", ""
        if s == "@sh" or s.startswith("@write"):
            kind = "sh" if s == "@sh" else "write"
            arg = "" if kind == "sh" else s[len("@write"):].strip()
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == END:
                    break
                body.append(nxt)
            return kind, arg, "\n".join(body)
    return None


def act(kind, arg, body, cwd):
    if kind == "sh":
        try:
            p = subprocess.run(body, shell=True, capture_output=True, text=True,
                               timeout=20, cwd=cwd)
            out = (p.stdout + p.stderr) or "(no output)"
            if p.returncode:
                out += f"\n[exit {p.returncode}]"
        except subprocess.TimeoutExpired:
            out = "(timed out after 20 s)"
        except Exception as e:
            out = f"(sh failed: {e})"
        return clip(out, OBS_CAP)
    if kind == "write":
        if not arg:
            return "error: @write needs a path"
        try:
            path = os.path.join(cwd, arg)
            d = os.path.dirname(path)
            if d:
                os.makedirs(d, exist_ok=True)
            text = body.rstrip("\n") + "\n"
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            return f"wrote {arg} ({len(text.encode('utf-8'))} bytes)"
        except Exception as e:
            return f"(write failed: {e})"
    return "error: unknown action"


def build_prompt(task, history, left):
    head = "TASK.md:\n" + task + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    budget = PROMPT_CAP - len(head) - len(tail) - 100
    kept = ""
    for h in reversed(history):
        if len(kept) + len(h) > budget:
            break
        kept = h + kept
    return head + kept + tail


def main():
    cwd = os.getcwd()
    try:
        with open(os.path.join(cwd, "TASK.md"), encoding="utf-8", errors="replace") as f:
            task = f.read()
    except OSError:
        task = "(no TASK.md found)"
    task = clip(task, PROMPT_CAP // 2)
    history = []
    for _ in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left)
        try:
            reply = cellapi.brain(SYSTEM, prompt)
        except cellapi.BudgetExhausted:
            break
        except Exception as e:
            history.append(f"[model error: {e}]\n")
            continue
        action = parse(reply)
        if action is None:
            history.append(f"--- your reply ---\n{clip(reply, REPLY_CAP)}\n"
                           "--- result ---\nNo valid action found. Reply with exactly one action.\n")
            continue
        kind, arg, body = action
        if kind == "done":
            break
        obs = act(kind, arg, body, cwd)
        history.append(f"--- your action ---\n{clip(reply, REPLY_CAP)}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    main()
