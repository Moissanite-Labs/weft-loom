"""Harness for the cell. Loop, prompt and tools. A builder may change any of it."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 4500       # characters of tool output shown back to the model
HIST_CAP = 11000     # upper bound on history kept in each prompt
PROMPT_CAP = 15000   # total prompt budget; the referee caps prompts at 16000
MAX_STEPS = 40       # the referee's call cap usually ends the episode first
CUT_MARK = "[earlier steps cut]\n"


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("@done"):
            return ("done", "", "")
        if s.startswith("@") and not s.startswith("@end"):
            head = s[1:].split(None, 1)
            name = head[0] if head else ""
            arg = head[1] if len(head) > 1 else ""
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return (name, arg.strip(), "\n".join(body))
    return None


def build_prompt(system, task, history, left):
    """Assemble the prompt so the whole thing fits PROMPT_CAP and the tail is never cut."""
    head = "TASK.md:\n" + task + "\n\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    room = PROMPT_CAP - len(system) - len(head) - len(tail)
    hist = "".join(history)
    limit = min(HIST_CAP, room)
    if len(hist) > limit:
        keep = max(limit - len(CUT_MARK), 0)
        hist = CUT_MARK + (hist[-keep:] if keep else "")
    return head + hist + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(system, task, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Reply with one @sh/@write block or @done."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
