"""Harness, turn 2. Adds a snapshot of the task folder to the first prompt, a larger
observation cap, and history trimming to the prompt budget."""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3500        # characters of tool output shown back to the model
MAX_STEPS = 40        # the referee's call cap usually ends the episode first
PROMPT_BUDGET = 14500 # keep each prompt safely under the 16000-character limit
SNAP_MD_CAP = 3000    # per .md file in the snapshot
SNAP_DATA_CAP = 300   # per data file in the snapshot
SNAP_TOTAL_CAP = 7000


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def _read(path, cap):
    with open(path, errors="replace") as f:
        return f.read(cap)


def snapshot(cwd):
    """A compact view of the task folder, so the model does not need calls to look around."""
    entries = []
    for root, dirs, files in os.walk(cwd):
        dirs.sort()
        for f in sorted(files):
            p = os.path.join(root, f)
            entries.append((os.path.relpath(p, cwd), os.path.getsize(p), p))
    out = ["FILES:"]
    for rel, size, _ in entries[:80]:
        out.append(f"  {rel} ({size} bytes)")
    text = "\n".join(out) + "\n"
    budget = SNAP_TOTAL_CAP
    for rel, size, p in entries:
        if budget <= 0:
            break
        if rel == "TASK.md" or rel.startswith("answer"):
            continue
        if rel.endswith(".md"):
            chunk = f"\n== {rel}\n" + _read(p, SNAP_MD_CAP) + "\n"
        elif "traces" not in rel and size <= 200000:
            chunk = f"\n== {rel} (first {SNAP_DATA_CAP} chars)\n" + _read(p, SNAP_DATA_CAP) + "\n"
        else:
            continue
        chunk = chunk[:budget]
        text += chunk
        budget -= len(chunk)
    return text


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    snap = snapshot(cwd)
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        head = "TASK.md:\n" + task + "\n\n" + snap
        tail = f"\nModel calls left: {left}. Your next action:"
        # keep the newest history entries that fit the budget
        kept = []
        used = len(system) + len(head) + len(tail)
        for entry in reversed(history):
            if used + len(entry) > PROMPT_BUDGET:
                break
            kept.append(entry)
            used += len(entry)
        prompt = head + "".join(reversed(kept)) + tail
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
