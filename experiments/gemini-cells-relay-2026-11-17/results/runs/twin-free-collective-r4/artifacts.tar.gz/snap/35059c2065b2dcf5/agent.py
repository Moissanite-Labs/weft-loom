"""Harness for cell B's turn-2 candidate.

Before the first model call, the harness reads the task folder (rules docs, expected
outputs, rates, data heads) and puts it in the prompt, so the model does not spend its
few calls on listing and reading files.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 2000
MAX_STEPS = 40
PRELOAD_BUDGET = 7000
PRELOAD_CHUNK = 6000
HIST_BUDGET = 2500
LIST_BUDGET = 800


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("<bash"):
            s = "@sh" + s[5:]
        if s.startswith("@") and not s.startswith("@end"):
            head = s[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def scan(cwd):
    rels = []
    for root, dirs, fs in os.walk(cwd):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for f in sorted(fs):
            if not f.startswith("."):
                rels.append(os.path.relpath(os.path.join(root, f), cwd))
    return sorted(r for r in rels if r != "TASK.md")


def prio(rel):
    base = os.path.basename(rel)
    if base in ("FORMAT.md", "SPEC.md"):
        return 0
    if rel.endswith("expected.json"):
        return 1
    if base == "rates.json":
        return 2
    if rel.startswith("example" + os.sep):
        return 3
    return 4


def preload(cwd, rels):
    out = []
    used = 0
    for r in sorted(rels, key=lambda x: (prio(x), x)):
        if used >= PRELOAD_BUDGET:
            out.append("[more files not shown; list and read them with sh]\n")
            break
        path = os.path.join(cwd, r)
        try:
            with open(path, "rb") as fh:
                raw = fh.read(PRELOAD_CHUNK)
            more = os.path.getsize(path) > PRELOAD_CHUNK
        except OSError:
            continue
        text = raw.decode("utf-8", "replace")
        block = "--- " + r + " ---\n" + text + ("\n[cut]" if more else "") + "\n"
        room = PRELOAD_BUDGET - used
        if len(block) > room:
            block = block[:room] + "\n[cut]\n"
        out.append(block)
        used += len(block)
    return "".join(out)


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    rels = scan(cwd)
    try:
        pre = preload(cwd, rels)
    except Exception as exc:
        pre = "(preload failed: %s)" % exc
    listing = ", ".join(rels)[:LIST_BUDGET]
    static = ("TASK.md:\n" + task + "\n\nFiles in your folder: " + listing
              + "\n\nPreloaded contents (read by the harness; use sh for anything else):\n" + pre + "\n")
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        hist = "".join(history)
        if len(hist) > HIST_BUDGET:
            hist = "[earlier steps dropped]\n" + hist[-HIST_BUDGET:]
        note = "Model calls left: %d." % left
        if left == 1:
            note += " This is your LAST call: write the required output file in this action."
        prompt = static + hist + "\n" + note + " Your next action:"
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = "Unknown tool %s." % action[0]
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = "Tool error: %s: %s" % (type(exc).__name__, exc)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append("\n--- step %d ---\n%s\n--- result ---\n%s\n" % (step + 1, reply.strip(), obs))


if __name__ == "__main__":
    sys.exit(main())
