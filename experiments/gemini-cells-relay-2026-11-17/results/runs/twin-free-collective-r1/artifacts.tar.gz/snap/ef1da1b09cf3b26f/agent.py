"""Harness for a cell. Run with the task folder as the working directory.

The model is reached only through cellapi. Tools live in tools/*.py.
"""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 7000        # characters of tool output shown back to the model
PROMPT_CAP = 14000    # keep the whole prompt under the referee's 16000 limit
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def cap(text, limit):
    if len(text) <= limit:
        return text
    half = limit // 2
    return text[:half] + "\n...[cut " + str(len(text) - limit) + " chars]...\n" + text[-half:]


def build_prompt(task, history, left):
    head = "TASK.md:\n" + task + "\n\n"
    note = ("\nThis is your last model call. Whatever you reply now is the final action, "
            "so make it the one that completes the task.\n") if left == 1 else ""
    tail = note + f"\nModel calls left: {left}. Your next action:"
    room = PROMPT_CAP - len(head) - len(tail)
    # keep the most recent history that fits; the oldest entries go first
    kept = []
    used = 0
    for entry in reversed(history):
        if used + len(entry) > room:
            break
        kept.append(entry)
        used += len(entry)
    body = "".join(reversed(kept))
    if len(kept) < len(history):
        body = "[earlier steps omitted to fit the prompt limit]\n" + body
    return head + body + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form, one action per reply."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool: {action[0]}. Available: {', '.join(tools)}"
        else:
            name, arg, body = action
            try:
                obs = tools[name].run(arg, body, {"cwd": cwd})
            except Exception as e:  # a failing tool must not end the episode
                obs = f"Tool error: {type(e).__name__}: {e}"
            obs = cap(str(obs), OBS_CAP)
        entry = f"\n=== step {step + 1} ===\nYou replied:\n{(reply or '')[:2000]}\n\nResult:\n{obs}\n"
        history.append(entry)


if __name__ == "__main__":
    main()
