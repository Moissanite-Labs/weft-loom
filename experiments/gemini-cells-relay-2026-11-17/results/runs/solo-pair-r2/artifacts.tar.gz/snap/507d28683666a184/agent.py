"""Harness for a cell. The loop, the prompt and the tools a cell starts with.

Run with the task folder as the working directory. The model is reached through cellapi.
"""
import importlib.util
import os

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3500        # characters of tool output shown back to the model (head + tail)
LIMIT = 15000         # keep system + prompt under the referee's per-prompt limit
TASK_CAP = 6000       # longest TASK.md text shown verbatim
MAX_STEPS = 40        # the referee's call cap usually ends the episode first


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("@") and not s.startswith("@end"):
            head = s[1:].split(None, 1)
            name = head[0] if head else ""
            arg = head[1] if len(head) > 1 else ""
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return name, arg, "\n".join(body)
    return None


def cap(text, n=OBS_CAP):
    if len(text) <= n:
        return text
    half = n // 2
    return text[:half] + "\n...[cut %d chars]...\n" % (len(text) - n) + text[-half:]


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    if len(task) > TASK_CAP:
        task = cap(task, TASK_CAP)

    entries = []  # (model reply, observation), oldest first

    for _ in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        head = "TASK.md:\n" + task + "\n\n"
        tail = "\nModel calls left: %d. Your next action:" % left
        room = LIMIT - len(system) - len(head) - len(tail) - 200
        # Keep the most recent steps that fit; the oldest are dropped first.
        kept = []
        used = 0
        for reply, obs in reversed(entries):
            block = "[your action]\n" + reply.strip() + "\n[result]\n" + obs + "\n\n"
            if used + len(block) > room:
                break
            kept.append(block)
            used += len(block)
        history = "".join(reversed(kept))
        if len(kept) < len(entries):
            history = "[earlier steps dropped to fit the prompt limit]\n" + history
        prompt = head + history + tail

        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = "Unknown tool %s." % action[0]
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as e:  # report tool errors to the model
                obs = "Tool error: %r" % (e,)
        entries.append((reply, cap(str(obs))))


if __name__ == "__main__":
    main()
