"""Harness for a cell. Run with the task folder as the working directory.

The model is reached through cellapi. Tools live in tools/ and are loaded by NAME.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 6000          # characters of tool output shown back to the model per step
PROMPT_BUDGET = 14000   # keep each prompt well under the referee's 16000-character limit
MAX_STEPS = 40


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        s = line.strip()
        if not s.startswith("@") or s.startswith("@end"):
            continue
        head = s[1:].split()
        if not head:
            continue
        if head[0] == "done":
            return ("done", "", "")
        body = []
        for nxt in lines[i + 1:]:
            if nxt.strip() == "@end":
                break
            body.append(nxt)
        arg = " ".join(head[1:])
        return head[0], arg, "\n".join(body)
    return None


def build_prompt(task, history, left):
    tail = f"\nModel calls left: {left}. Your next action:"
    room = PROMPT_BUDGET - len(task) - len(tail) - 20
    kept = []
    # newest steps first; the most recent results matter most
    for entry in reversed(history):
        if len(entry) <= room:
            kept.append(entry)
            room -= len(entry)
        else:
            break
    kept.reverse()
    return "TASK.md:\n" + task + "\n\n" + "".join(kept) + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        system = f.read() + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left)
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}."
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        obs = str(obs)
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + "\n[output cut]"
        history.append(f"\n--- step {step + 1} ---\n{reply.strip()}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
