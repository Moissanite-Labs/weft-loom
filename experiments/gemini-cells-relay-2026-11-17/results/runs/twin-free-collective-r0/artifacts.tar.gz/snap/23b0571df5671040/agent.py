"""Harness for cell A's benchmark. The loop, the prompt and the tools a cell starts with.

Run with the task folder as the working directory. The model is reached through cellapi,
which the referee provides. Everything in this folder may be changed by a builder.
"""
import importlib.util
import os
import sys

import cellapi

HERE = os.path.dirname(os.path.abspath(__file__))
OBS_CAP = 3000        # characters of tool output kept in the history and shown back
REPLY_CAP = 5000      # characters of a model reply kept in the history
PROMPT_LIMIT = 15500  # system + prompt together, kept under the referee's 16000
MAX_STEPS = 40        # the referee's call cap usually ends the episode first

STRATEGY = """
How to work well with few model calls:
- You have about 3 model calls. Spend them on reading, then solving, then fixing.
- Read every spec file completely. Print any file longer than 3000 characters in pieces, e.g.
  head -c 3000 FILE; echo; tail -c +3001 FILE | head -c 3000
  Never skip part of a spec: every rule matters, and the rules change from instance to instance.
- Print example/expected.json, and the header plus two lines of each data file, in compact form.
- Then write ONE complete script that implements every rule of the spec in the order given,
  covering every option the spec lists. It must run on the example, print only a short list of
  mismatches, and write the answer file for the real data. Run it in the same action.
- Then fix the script from the printed output and rerun it. The answer file must exist before you finish.
- Keep each tool output under 3000 characters: print summaries, not raw dumps.
- For code-fixing tasks: read the code with cat -n, compare it with the contract at boundaries and
  edge cases (empty input, equal values, last element, repeated items), and fix the bugs in place.
- Finish with @done only after the answer is written and checked.
"""


def load_tools():
    tools = {}
    folder = os.path.join(HERE, "tools")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and not name.startswith("_"):
            spec = importlib.util.spec_from_file_location(name[:-3], os.path.join(folder, name))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            tools[mod.NAME] = mod
    return tools


def parse(reply):
    """Return (tool, arg, body) for the first action in the reply, or None."""
    lines = reply.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("@") and not line.startswith("@end"):
            head = line[1:].split(None, 1)
            if not head:
                continue
            body = []
            for nxt in lines[i + 1:]:
                if nxt.strip() == "@end":
                    break
                body.append(nxt)
            return head[0], (head[1] if len(head) > 1 else ""), "\n".join(body)
    return None


def build_prompt(task, history, left, limit):
    """Assemble the prompt so that it never exceeds `limit` characters.

    The task is always shown. The first steps are pinned (they hold the spec reading), and the
    most recent steps are kept. Middle steps are dropped with a note. Each step is capped so one
    large result cannot crowd out the others.
    """
    step_cap = 3500
    head = "TASK.md:\n"
    tail = f"\nModel calls left: {left}. Your next action:"
    note = "[some earlier steps dropped to fit the prompt limit]\n"
    room = limit - len(head) - len(tail) - 2
    if len(task) > room - 200:
        task = task[:max(0, room - 200)] + "\n[TASK.md cut to fit the prompt limit]"
    room -= len(task)
    items = []
    for h in history:
        if len(h) > step_cap:
            h = h[:step_cap] + "\n[step cut to fit the prompt limit]\n"
        items.append(h)
    pinned = []
    used = 0
    pin_budget = room * 2 // 5
    i = 0
    while i < len(items) and used + len(items[i]) <= pin_budget:
        pinned.append(items[i])
        used += len(items[i])
        i += 1
    rest = items[i:]
    avail = room - used - len(note)
    recent = []
    for h in reversed(rest):
        if len(h) <= avail:
            recent.insert(0, h)
            avail -= len(h)
        else:
            break
    dropped = len(rest) - len(recent)
    mid = note if dropped > 0 else ""
    return head + task + "\n\n" + "".join(pinned) + mid + "".join(recent) + tail


def main():
    cwd = os.getcwd()
    tools = load_tools()
    with open(os.path.join(HERE, "prompt.md")) as f:
        base = f.read()
    system = base + "\n" + STRATEGY + "\nTools:\n" + "\n".join(t.HELP for t in tools.values())
    with open(os.path.join(cwd, "TASK.md")) as f:
        task = f.read()
    history = []
    for step in range(MAX_STEPS):
        left = cellapi.calls_left()
        if left <= 0:
            break
        prompt = build_prompt(task, history, left, PROMPT_LIMIT - len(system))
        try:
            reply = cellapi.brain(system, prompt)
        except cellapi.BudgetExhausted:
            break
        action = parse(reply)
        if action is None:
            obs = "Could not read an action. Use the @tool ... @end form, one action per reply."
        elif action[0] == "done":
            break
        elif action[0] not in tools:
            obs = f"Unknown tool {action[0]}. Available: " + ", ".join(sorted(tools))
        else:
            try:
                obs = tools[action[0]].run(action[1], action[2], {"cwd": cwd})
            except Exception as exc:
                obs = f"Tool error: {type(exc).__name__}: {exc}"
        if len(obs) > OBS_CAP:
            obs = obs[:OBS_CAP] + f"\n[output cut at {OBS_CAP} chars; see the rest with tail -c +{OBS_CAP + 1}]"
        shown = reply.strip()
        if len(shown) > REPLY_CAP:
            shown = shown[:REPLY_CAP] + "\n[reply cut]"
        history.append(f"\n--- step {step + 1} ---\n{shown}\n--- result ---\n{obs}\n")


if __name__ == "__main__":
    sys.exit(main())
